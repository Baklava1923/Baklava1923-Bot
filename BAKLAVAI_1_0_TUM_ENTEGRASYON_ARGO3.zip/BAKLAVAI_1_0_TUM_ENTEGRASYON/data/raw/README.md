Bu klasöre eğitim için kullanım izniniz olan UTF-8 .txt dosyalarını koyun. README dosyası veri olarak okunmaz.
