# Eğitim verisi klasörü

Buraya `.txt` uzantılı, UTF-8 kodlamalı ve kullanım/eğitim izniniz olan metinleri koyun.

- Kendi yazdığınız örnekleri kullanabilirsiniz.
- Kamu malı veya lisansı model eğitimi için açıkça izin veren metinleri kullanın.
- Discord özel mesajlarını, gerçek kişilerin kişisel bilgilerini, şifreleri, tokenları veya okul kayıtlarını eklemeyin.
- Her metnin kaynağını ve lisansını `data/sources.json` dosyasında belgeleyin.
- Sadece eğitim hakkı olan metinler kullanın; bir web sayfasını okuyabilmek o sayfayı model eğitimi için kullanma izni vermez.

Eğitim verisi eklenene kadar bu klasör model kalitesini artırmaz.
