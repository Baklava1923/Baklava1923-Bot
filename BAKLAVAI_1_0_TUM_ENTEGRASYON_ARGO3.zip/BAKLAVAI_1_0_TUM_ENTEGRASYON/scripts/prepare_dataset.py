"""Normalize UTF-8 text files and create a source/size/hash manifest."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description="BAKLAVAI dataset preparation")
    parser.add_argument("--source", default="data/raw")
    parser.add_argument("--output", default="data/train")
    args = parser.parse_args()
    source, output = Path(args.source), Path(args.output)
    if not source.exists():
        raise SystemExit(f"Kaynak klasör yok: {source}")
    output.mkdir(parents=True, exist_ok=True)
    seen = set()
    manifest = []
    for path in sorted(source.rglob("*.txt")):
        text = path.read_text(encoding="utf-8-sig").replace("\r\n", "\n").replace("\r", "\n")
        cleaned = "\n".join(line.rstrip() for line in text.splitlines()).strip()
        if not cleaned:
            continue
        digest = hashlib.sha256(cleaned.encode("utf-8")).hexdigest()
        if digest in seen:
            print(f"Tekrar atlandı: {path}")
            continue
        seen.add(digest)
        target = output / f"{path.stem}_{digest[:8]}.txt"
        target.write_text(cleaned + "\n", encoding="utf-8")
        manifest.append({"file": str(target), "source_file": str(path), "sha256": digest,
                         "characters": len(cleaned), "utf8_bytes": len(cleaned.encode("utf-8")),
                         "license": "REQUIRES_MANUAL_CONFIRMATION"})
        print(f"Hazırlandı: {target}")
    manifest_path = output.parent / "dataset_manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"{len(manifest)} dosya | manifest: {manifest_path}")
    print("Her dosyanın lisansını kontrol etmeden model eğitiminde kullanma.")

if __name__ == "__main__":
    main()
