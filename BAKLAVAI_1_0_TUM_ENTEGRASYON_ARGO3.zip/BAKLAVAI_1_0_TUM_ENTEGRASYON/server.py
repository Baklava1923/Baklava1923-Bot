"""Minimal local HTTP interface; standard library only beyond project dependencies."""
from __future__ import annotations
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import hmac

from baklavaai.config import AppConfig
from baklavaai.runtime import BaklavaRuntime, ModelNotReadyError

CONFIG = AppConfig.from_env()
RUNTIME = BaklavaRuntime(CONFIG)

class Handler(BaseHTTPRequestHandler):
    server_version = "BaklavaAI/1.0"

    def _json(self, status: int, payload: dict):
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def _authorized(self) -> bool:
        if not CONFIG.api_token:
            return True
        supplied = self.headers.get("Authorization", "")
        expected = f"Bearer {CONFIG.api_token}"
        return hmac.compare_digest(supplied, expected)

    def do_GET(self):
        if self.path == "/health":
            return self._json(200, {"ok": True, "model_loaded": RUNTIME.model is not None, "name": CONFIG.app_name, "version": CONFIG.version})
        if self.path == "/v1/models":
            return self._json(200, {"data": [{"id": "baklavaai-local", "object": "model"}]})
        return self._json(404, {"error": {"message": "Not found"}})

    def do_POST(self):
        if not self._authorized():
            return self._json(401, {"error": {"message": "Unauthorized"}})
        if self.path != "/v1/chat/completions":
            return self._json(404, {"error": {"message": "Not found"}})
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if not 1 <= size <= 64000:
                return self._json(413, {"error": {"message": "Request body must be 1..64000 bytes"}})
            body = json.loads(self.rfile.read(size).decode("utf-8"))
            messages = body.get("messages", [])
            if not isinstance(messages, list) or not all(isinstance(item, dict) for item in messages):
                return self._json(400, {"error": {"message": "messages must be a list of objects"}})
            user_message = next((m.get("content", "") for m in reversed(messages) if m.get("role") == "user"), "")
            if not isinstance(user_message, str):
                return self._json(400, {"error": {"message": "Last user content must be plain text"}})
            session = str(body.get("user", "api"))[:80]
            requested_tokens = int(body.get("max_tokens", CONFIG.max_new_tokens))
            if not 1 <= requested_tokens <= 512:
                return self._json(400, {"error": {"message": "max_tokens must be between 1 and 512"}})
            answer = RUNTIME.chat(user_message, session_id=session, max_new_tokens=requested_tokens)
            return self._json(200, {"id": "baklavaai-response", "object": "chat.completion", "choices": [{"index": 0, "message": {"role": "assistant", "content": answer}, "finish_reason": "stop"}]})
        except ModelNotReadyError as exc:
            return self._json(503, {"error": {"message": str(exc)}})
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError) as exc:
            return self._json(400, {"error": {"message": f"Invalid request: {exc}"}})
        except Exception as exc:
            return self._json(500, {"error": {"message": f"Runtime error: {exc}"}})

    def log_message(self, fmt, *args):
        # Do not print user message bodies or private conversation text.
        print("HTTP", self.address_string(), fmt % args)


def main():
    try:
        RUNTIME.load()
    except ModelNotReadyError as exc:
        print(exc)
        raise SystemExit(2)
    server = ThreadingHTTPServer((CONFIG.api_host, CONFIG.api_port), Handler)
    print(f"BAKLAVAI API: http://{CONFIG.api_host}:{CONFIG.api_port}")
    print("Durdurmak için Ctrl+C")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()

if __name__ == "__main__":
    main()
