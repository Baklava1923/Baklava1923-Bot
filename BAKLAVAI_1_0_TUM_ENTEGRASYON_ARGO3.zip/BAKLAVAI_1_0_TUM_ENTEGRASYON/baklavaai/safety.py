"""Small policy layer for the demo runtime; not a complete safety classifier."""
from dataclasses import dataclass

@dataclass
class SafetyDecision:
    allowed: bool
    message: str = ""
    category: str = "ok"

# This list is intentionally narrow and transparent. It is not a general content classifier.
_BLOCK_PATTERNS = {
    "credential_theft": ("şifremi çal", "hesabını ele geçir", "token çal"),
    "malware": ("fidye yazılımı yap", "virüs yaz", "zararlı yazılım yap"),
}


def inspect_user_text(text: str) -> SafetyDecision:
    normalized = " ".join(text.casefold().split())
    for category, phrases in _BLOCK_PATTERNS.items():
        if any(phrase in normalized for phrase in phrases):
            return SafetyDecision(
                False,
                "Bu isteğe zarar verebilecek uygulamalı talimatlarla yardımcı olamam. Güvenli ve savunma amaçlı bir açıklama sunabilirim.",
                category,
            )
    return SafetyDecision(True)


def sanitize_generated_text(text: str, max_chars: int = 12000) -> str:
    """Bound output size; it does not claim to detect every unsafe output."""
    return text[:max_chars].strip()
