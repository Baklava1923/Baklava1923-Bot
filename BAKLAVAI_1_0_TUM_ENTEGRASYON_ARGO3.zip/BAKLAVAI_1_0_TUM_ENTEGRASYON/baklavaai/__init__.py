"""BAKLAVAI: an educational, from-scratch language-model project."""

__version__ = "1.0.0"
