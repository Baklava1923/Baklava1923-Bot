"""Configuration loading for BAKLAVAI. No secrets are stored in this file."""
from __future__ import annotations
from dataclasses import dataclass
import os


def _bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class AppConfig:
    app_name: str = "BAKLAVAI"
    version: str = "1.0.0"
    checkpoint: str = "checkpoints/baklavaai_latest.pt"
    memory_db: str = "data/baklavaai_memory.sqlite3"
    max_input_chars: int = 6000
    max_new_tokens: int = 160
    temperature: float = 0.85
    top_k: int = 40
    argo_level: int = 3
    memory_enabled: bool = False
    api_host: str = "127.0.0.1"
    api_port: int = 8765
    api_token: str = ""

    @classmethod
    def from_env(cls) -> "AppConfig":
        cfg = cls(
            checkpoint=os.getenv("BAKLAVAI_CHECKPOINT", cls.checkpoint),
            memory_db=os.getenv("BAKLAVAI_MEMORY_DB", cls.memory_db),
            max_input_chars=int(os.getenv("BAKLAVAI_MAX_INPUT_CHARS", "6000")),
            max_new_tokens=int(os.getenv("BAKLAVAI_MAX_NEW_TOKENS", "160")),
            temperature=float(os.getenv("BAKLAVAI_TEMPERATURE", "0.85")),
            top_k=int(os.getenv("BAKLAVAI_TOP_K", "40")),
            argo_level=int(os.getenv("BAKLAVAI_ARGO_LEVEL", "3")),
            memory_enabled=_bool("BAKLAVAI_MEMORY_ENABLED", False),
            api_host=os.getenv("BAKLAVAI_API_HOST", "127.0.0.1"),
            api_port=int(os.getenv("BAKLAVAI_API_PORT", "8765")),
            api_token=os.getenv("BAKLAVAI_API_TOKEN", ""),
        )
        if not 100 <= cfg.max_input_chars <= 50000:
            raise ValueError("BAKLAVAI_MAX_INPUT_CHARS must be between 100 and 50000")
        if not 1 <= cfg.max_new_tokens <= 2048:
            raise ValueError("BAKLAVAI_MAX_NEW_TOKENS must be between 1 and 2048")
        if not 0.05 <= cfg.temperature <= 2.0:
            raise ValueError("BAKLAVAI_TEMPERATURE must be between 0.05 and 2.0")
        if cfg.top_k < 0 or not 0 <= cfg.argo_level <= 3:
            raise ValueError("top_k must be >= 0 and argo_level must be 0..3")
        if not 1 <= cfg.api_port <= 65535:
            raise ValueError("BAKLAVAI_API_PORT must be between 1 and 65535")
        return cfg
