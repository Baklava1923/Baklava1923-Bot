"""A simple UTF-8 byte tokenizer. It needs no downloaded vocabulary."""

BOS = 256
EOS = 257
VOCAB_SIZE = 258


def encode(text: str, add_bos: bool = False, add_eos: bool = False) -> list[int]:
    if not isinstance(text, str):
        raise TypeError("text must be a string")
    ids = list(text.encode("utf-8"))
    if add_bos:
        ids.insert(0, BOS)
    if add_eos:
        ids.append(EOS)
    return ids


def decode(ids: list[int]) -> str:
    raw = bytes(token for token in ids if 0 <= token <= 255)
    return raw.decode("utf-8", errors="replace")
