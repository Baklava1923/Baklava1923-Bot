"""Conversation formatting for the byte-level training prototype."""
from __future__ import annotations

STOP_MARKERS = ("\nU:", "\nKullanıcı:", "\n### Kullanıcı", "\nUser:")


def build_prompt(system_prompt: str, history: list[tuple[str, str]], user_text: str) -> str:
    chunks = [f"S:{system_prompt}\n"]
    for role, content in history[-4:]:
        if role == "assistant":
            chunks.append(f"A:{content}\n")
        else:
            chunks.append(f"U:{content}\n")
    chunks.append(f"U:{user_text}\nA:")
    return "".join(chunks)


def trim_at_stop(text: str) -> str:
    positions = [text.find(marker) for marker in STOP_MARKERS if text.find(marker) >= 0]
    return text[:min(positions)].strip() if positions else text.strip()
