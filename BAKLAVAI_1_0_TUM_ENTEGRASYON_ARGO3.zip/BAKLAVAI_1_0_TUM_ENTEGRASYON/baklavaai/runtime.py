"""Shared local runtime used by the terminal, HTTP API and Discord integration."""
from __future__ import annotations
from pathlib import Path
from threading import RLock
import torch

from .config import AppConfig
from .memory import LocalMemory
from .model import BaklavaGPT, ModelConfig
from .persona import Persona, VALID_STYLES
from .plugins import PluginRegistry
from .prompting import build_prompt, trim_at_stop
from .safety import inspect_user_text, sanitize_generated_text
from .tokenizer import BOS, encode, decode

class ModelNotReadyError(RuntimeError):
    """Raised when no trained checkpoint can be loaded."""

class BaklavaRuntime:
    def __init__(self, config: AppConfig | None = None):
        self.config = config or AppConfig.from_env()
        self.project_root = Path(__file__).resolve().parents[1]
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model: BaklavaGPT | None = None
        self.history: dict[str, list[tuple[str, str]]] = {}
        self.session_personas: dict[str, Persona] = {}
        self.plugins = PluginRegistry()
        memory_path = Path(self.config.memory_db)
        if not memory_path.is_absolute():
            memory_path = self.project_root / memory_path
        self.memory = LocalMemory(str(memory_path))
        self.persona = Persona(argo_level=self.config.argo_level)
        self._lock = RLock()

    def load(self, checkpoint: str | None = None) -> None:
        path = Path(checkpoint) if checkpoint else Path(self.config.checkpoint)
        if not path.is_absolute():
            path = (Path.cwd() / path) if checkpoint else (self.project_root / path)
        if not path.is_file():
            raise ModelNotReadyError(
                f"Model checkpoint bulunamadı: {path}. Önce izinli eğitim verileriyle train.py çalıştır."
            )
        try:
            state = torch.load(path, map_location=self.device, weights_only=True)
            cfg = ModelConfig(**state["config"])
            model = BaklavaGPT(cfg).to(self.device)
            model.load_state_dict(state["model_state"])
        except Exception as exc:
            raise RuntimeError(f"Model dosyası okunamadı: {exc}") from exc
        model.eval()
        with self._lock:
            self.model = model

    def chat(
        self,
        user_text: str,
        session_id: str = "default",
        remember_history: bool = True,
        max_new_tokens: int | None = None,
        style: str | None = None,
    ) -> str:
        text = user_text.strip()
        if not text:
            return "Bir mesaj yazmalısın."
        if len(text) > self.config.max_input_chars:
            return f"Mesaj çok uzun. En fazla {self.config.max_input_chars} karakter gönder."
        decision = inspect_user_text(text)
        if not decision.allowed:
            return decision.message
        if not isinstance(session_id, str) or not session_id or len(session_id) > 200:
            raise ValueError("session_id 1–200 karakter arasında olmalı")
        if style is not None:
            self.set_session_style(session_id, style)

        with self._lock:
            if self.model is None:
                raise ModelNotReadyError("Model henüz yüklenmedi. Önce eğitim yapıp checkpoint oluştur.")
            history = self.history.setdefault(session_id, []) if remember_history else []
            persona = self.session_personas.get(session_id, self.persona)
            system_prompt = persona.system_prompt()

            # Preserve the newest user message; add older turns only while they fit.
            prompt = build_prompt(system_prompt, [], text)
            if len(encode(prompt)) + 1 > self.model.config.context_length:
                usable = max(0, self.model.config.context_length - len(encode(f"S:{system_prompt}\nU:\nA:")) - 1)
                return f"Bu deneysel modelin bağlam penceresi çok kısa. Mesajını yaklaşık {usable} byte olacak şekilde kısalt."
            selected_history: list[tuple[str, str]] = []
            for pair in reversed(history[-8:]):
                candidate = [pair, *selected_history]
                candidate_prompt = build_prompt(system_prompt, candidate, text)
                if len(encode(candidate_prompt)) + 1 <= self.model.config.context_length:
                    selected_history = candidate
                else:
                    break
            prompt = build_prompt(system_prompt, selected_history, text)
            ids = [BOS, *encode(prompt)]
            token_budget = self.config.max_new_tokens if max_new_tokens is None else max_new_tokens
            if not 1 <= token_budget <= 2048:
                raise ValueError("max_new_tokens must be between 1 and 2048")
            context = torch.tensor([ids], dtype=torch.long, device=self.device)
            with torch.inference_mode():
                generated = self.model.generate(
                    context,
                    max_new_tokens=token_budget,
                    temperature=self.config.temperature,
                    top_k=self.config.top_k,
                )
            new_ids = generated[0, context.shape[1]:].tolist()
            answer = sanitize_generated_text(trim_at_stop(decode(new_ids)))
            if not answer:
                answer = "Henüz düzgün bir cevap üretemedim. Daha fazla ve kaliteli eğitim verisi gerekiyor."
            if remember_history:
                history.extend([( "user", text), ("assistant", answer)])
                self.history[session_id] = history[-16:]
            return answer

    def reset_session(self, session_id: str) -> None:
        with self._lock:
            self.history.pop(session_id, None)

    def set_session_argo(self, session_id: str, level: int) -> None:
        if level not in range(4):
            raise ValueError("argo level must be 0..3")
        with self._lock:
            persona = self.session_personas.get(session_id, self.persona)
            self.session_personas[session_id] = Persona(argo_level=level, style=persona.style)

    def set_session_style(self, session_id: str, style: str) -> None:
        style = style.strip().lower()
        if style not in VALID_STYLES:
            raise ValueError(f"style must be one of: {', '.join(sorted(VALID_STYLES))}")
        with self._lock:
            persona = self.session_personas.get(session_id, self.persona)
            self.session_personas[session_id] = Persona(argo_level=persona.argo_level, style=style)

    def get_session_persona(self, session_id: str) -> Persona:
        with self._lock:
            persona = self.session_personas.get(session_id, self.persona)
            return Persona(argo_level=persona.argo_level, style=persona.style)
