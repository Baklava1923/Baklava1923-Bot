"""Optional Cog that reuses the bot's shared BAKLAVAI bridge.

Do not load this Cog inside the bundled 3.7 bot unless you specifically want
its alternate command names; the main bot already exposes B!baklava.
"""
from __future__ import annotations
import discord
from discord.ext import commands

from ..discord_bridge import DiscordBaklavaBridge

class BaklavaAICog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        bridge = getattr(bot, "baklavaai", None)
        if bridge is None:
            bridge = DiscordBaklavaBridge(bot)
            setattr(bot, "baklavaai", bridge)
        self.bridge = bridge

    @commands.command(name="bai-cog")
    @commands.cooldown(2, 8, commands.BucketType.user)
    async def baklava_chat(self, ctx: commands.Context, *, message: str):
        """Alternate command for an external bot that loads this Cog."""
        async with ctx.typing():
            response = await self.bridge.achat(
                message, ctx.guild.id if ctx.guild else None,
                ctx.author.id, style="normal",
            )
        await ctx.reply(
            response[:1900], mention_author=False,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @commands.command(name="bai-cog-reset")
    async def reset_chat(self, ctx: commands.Context):
        self.bridge.reset(ctx.guild.id if ctx.guild else None, ctx.author.id)
        await ctx.reply("BAKLAVAI sohbet bağlamın temizlendi.", mention_author=False)

async def setup(bot: commands.Bot):
    cog = BaklavaAICog(bot)
    if not cog.bridge.model_loaded:
        cog.bridge.load_model()
    await bot.add_cog(cog)
