"""Adapters that expose the same BAKLAVAI core to external applications."""
