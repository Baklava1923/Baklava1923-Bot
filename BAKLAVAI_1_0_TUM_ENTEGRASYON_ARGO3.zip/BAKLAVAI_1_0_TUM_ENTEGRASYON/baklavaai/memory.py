"""Opt-in local memory. No conversation is stored automatically."""
from __future__ import annotations
import sqlite3
from pathlib import Path

class LocalMemory:
    def __init__(self, database: str = "data/baklavaai_memory.sqlite3"):
        self.database = Path(database)
        self.database.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self):
        connection = sqlite3.connect(self.database)
        connection.execute("PRAGMA journal_mode=WAL")
        return connection

    def _initialize(self) -> None:
        with self._connect() as con:
            con.execute("CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY, note TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP)")

    def save_note(self, note: str) -> int:
        clean = " ".join(note.strip().split())
        if not clean:
            raise ValueError("Not boş olamaz")
        if len(clean) > 1000:
            raise ValueError("Not en fazla 1000 karakter olabilir")
        with self._connect() as con:
            cur = con.execute("INSERT INTO notes(note) VALUES (?)", (clean,))
            return int(cur.lastrowid)

    def get_notes(self, limit: int = 20) -> list[tuple[int, str, str]]:
        if not 1 <= limit <= 100:
            raise ValueError("limit 1 ile 100 arasında olmalı")
        with self._connect() as con:
            return con.execute("SELECT id, note, created_at FROM notes ORDER BY id DESC LIMIT ?", (limit,)).fetchall()

    def delete_note(self, note_id: int) -> bool:
        with self._connect() as con:
            cur = con.execute("DELETE FROM notes WHERE id = ?", (note_id,))
            return cur.rowcount > 0

    def clear(self) -> None:
        with self._connect() as con:
            con.execute("DELETE FROM notes")
