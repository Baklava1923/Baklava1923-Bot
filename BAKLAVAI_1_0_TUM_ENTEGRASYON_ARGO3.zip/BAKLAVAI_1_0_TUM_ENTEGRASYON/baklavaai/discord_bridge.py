"""Bridge that makes the same BAKLAVAI runtime available to the main Discord bot.

This module deliberately loads PyTorch lazily: the moderation/economy bot can still
start if the optional local-model dependency or a trained checkpoint is unavailable.
"""
from __future__ import annotations
from typing import Any
import asyncio

class DiscordBaklavaBridge:
    def __init__(self, bot: Any):
        self.bot = bot
        self.runtime = None
        self.load_error: str | None = None
        self.model_loaded = False
        self._register_error: str | None = None
        try:
            from .config import AppConfig
            from .runtime import BaklavaRuntime
            self.runtime = BaklavaRuntime(AppConfig.from_env())
            self._register_read_only_plugins()
        except Exception as exc:
            self.load_error = f"BAKLAVAI çekirdeği yüklenemedi: {type(exc).__name__}: {exc}"

    def _register_read_only_plugins(self) -> None:
        if self.runtime is None:
            return
        from .plugins import Plugin

        def bot_status(_: dict[str, Any]) -> str:
            ready = bool(self.bot.is_ready())
            ping = round(self.bot.latency * 1000) if ready else None
            return f"Bot: {'çevrimiçi' if ready else 'hazır değil'} | Sunucu: {len(self.bot.guilds)} | Ping: {ping if ping is not None else '—'} ms"

        def command_catalog(_: dict[str, Any]) -> str:
            names = sorted({command.qualified_name for command in self.bot.walk_commands()})
            return "Kayıtlı komutlar: " + ", ".join(names[:100])

        def guild_summary(arguments: dict[str, Any]) -> str:
            try:
                guild_id = int(arguments["guild_id"])
            except (KeyError, TypeError, ValueError):
                return "Geçerli guild_id verilmedi."
            guild = self.bot.get_guild(guild_id)
            if guild is None:
                return "Sunucu bulunamadı veya bot bu sunucuda değil."
            humans = sum(not member.bot for member in guild.members)
            return (
                f"Sunucu: {guild.name} | Üye: {guild.member_count or len(guild.members)} "
                f"(önbellekte {humans} insan) | Metin kanalı: "
                f"{sum(c.type.name == 'text' for c in guild.channels)} | Rol: {len(guild.roles)}"
            )

        self.runtime.plugins.register(Plugin(
            name="bot_durumu", description="Botun çevrimiçi durumu ve ping bilgisi",
            handler=bot_status,
        ))
        self.runtime.plugins.register(Plugin(
            name="komut_listesi", description="Botta kayıtlı komut adlarını listeler",
            handler=command_catalog,
        ))
        self.runtime.plugins.register(Plugin(
            name="sunucu_ozeti", description="Geçerli Discord sunucusunun temel sayımlarını verir",
            handler=guild_summary, required_arguments=("guild_id",),
            allowed_arguments=("guild_id",),
        ))

    def load_model(self) -> bool:
        if self.runtime is None:
            return False
        try:
            self.runtime.load()
            self.model_loaded = True
            self.load_error = None
            return True
        except Exception as exc:
            self.model_loaded = False
            self.load_error = str(exc)
            return False

    @staticmethod
    def session_id(guild_id: int | None, user_id: int) -> str:
        return f"discord:{guild_id or 0}:{user_id}"

    def chat(self, text: str, guild_id: int | None, user_id: int, style: str = "normal", images: list[str] | None = None) -> str:
        if images:
            return "BAKLAVAI 1.0 görüntü modülü henüz eğitilmedi. Görseli şu an inceleyemiyorum; yalnızca metin mesajlarını yanıtlayabiliyorum."
        if self.runtime is None:
            return self.load_error or "BAKLAVAI çekirdeği kullanılamıyor."
        if not self.model_loaded:
            return "BAKLAVAI 1.0 henüz eğitilmiş model dosyası bulamadı. Önce eğitim yapıp checkpoints/baklavaai_latest.pt dosyasını oluşturmalıyız."
        return self.runtime.chat(text, session_id=self.session_id(guild_id, user_id), style=style)

    async def achat(self, text: str, guild_id: int | None, user_id: int, style: str = "normal", images: list[str] | None = None) -> str:
        """Async entry point for every Discord Cog/extension sharing this bridge."""
        return await asyncio.to_thread(self.chat, text, guild_id, user_id, style, images)

    def reset(self, guild_id: int | None, user_id: int) -> None:
        if self.runtime:
            self.runtime.reset_session(self.session_id(guild_id, user_id))

    def set_argo(self, guild_id: int | None, user_id: int, level: int) -> None:
        if not self.runtime:
            raise RuntimeError(self.load_error or "BAKLAVAI hazır değil")
        self.runtime.set_session_argo(self.session_id(guild_id, user_id), level)

    def set_style(self, guild_id: int | None, user_id: int, style: str) -> None:
        if not self.runtime:
            raise RuntimeError(self.load_error or "BAKLAVAI hazır değil")
        self.runtime.set_session_style(self.session_id(guild_id, user_id), style)

    def status(self) -> dict[str, Any]:
        if self.runtime is None:
            return {"loaded": False, "device": "yok", "parameters": 0, "error": self.load_error}
        parameters = self.runtime.model.parameter_count() if self.runtime.model is not None else 0
        return {
            "loaded": bool(self.model_loaded and self.runtime.model is not None),
            "device": str(self.runtime.device),
            "parameters": parameters,
            "error": self.load_error,
            "plugins": self.runtime.plugins.list_plugins(),
            "memory_enabled": self.runtime.config.memory_enabled,
        }

    def list_plugins(self) -> list[dict[str, str]]:
        if not self.runtime:
            return []
        return self.runtime.plugins.list_plugins()

    def call_read_only_plugin(self, name: str, guild_id: int | None = None) -> str:
        if not self.runtime:
            return self.load_error or "BAKLAVAI hazır değil."
        arguments: dict[str, Any] = {}
        if name.strip().lower() == "sunucu_ozeti":
            if guild_id is None:
                return "Bu araç yalnızca sunucu kanalında kullanılabilir."
            arguments["guild_id"] = str(guild_id)
        return self.runtime.plugins.call(name, arguments)
