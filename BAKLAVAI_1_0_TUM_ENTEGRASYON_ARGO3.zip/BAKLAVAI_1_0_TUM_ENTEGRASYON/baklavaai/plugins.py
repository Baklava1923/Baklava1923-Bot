"""Explicit plugin registry. Model text is never executed as Python or shell."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Any

@dataclass(frozen=True)
class Plugin:
    name: str
    description: str
    handler: Callable[[dict[str, Any]], str]
    enabled: bool = True
    required_arguments: tuple[str, ...] = ()
    allowed_arguments: tuple[str, ...] = ()

class PluginRegistry:
    def __init__(self) -> None:
        self._plugins: dict[str, Plugin] = {}

    def register(self, plugin: Plugin) -> None:
        key = plugin.name.strip().lower()
        if not key or key in self._plugins:
            raise ValueError("Plugin name is empty or already registered")
        if len(plugin.description) > 500:
            raise ValueError("Plugin description is too long")
        self._plugins[key] = plugin

    def list_plugins(self) -> list[dict[str, str]]:
        return [
            {"name": p.name, "description": p.description, "enabled": str(p.enabled).lower()}
            for p in self._plugins.values()
        ]

    def set_enabled(self, name: str, enabled: bool) -> None:
        key = name.strip().lower()
        plugin = self._plugins.get(key)
        if plugin is None:
            raise KeyError(f"Plugin not found: {name}")
        self._plugins[key] = Plugin(
            name=plugin.name, description=plugin.description, handler=plugin.handler,
            enabled=bool(enabled), required_arguments=plugin.required_arguments,
            allowed_arguments=plugin.allowed_arguments,
        )

    def call(self, name: str, arguments: dict[str, Any]) -> str:
        plugin = self._plugins.get(name.strip().lower())
        if plugin is None or not plugin.enabled:
            raise KeyError(f"Plugin not found or disabled: {name}")
        if not isinstance(arguments, dict):
            raise TypeError("Plugin arguments must be a JSON object")
        missing = set(plugin.required_arguments) - set(arguments)
        if missing:
            raise ValueError(f"Missing plugin arguments: {', '.join(sorted(missing))}")
        if plugin.allowed_arguments:
            extra = set(arguments) - set(plugin.allowed_arguments)
            if extra:
                raise ValueError(f"Unexpected plugin arguments: {', '.join(sorted(extra))}")
        result = plugin.handler(arguments)
        if not isinstance(result, str):
            raise TypeError("Plugin handlers must return text")
        return result[:8000]
