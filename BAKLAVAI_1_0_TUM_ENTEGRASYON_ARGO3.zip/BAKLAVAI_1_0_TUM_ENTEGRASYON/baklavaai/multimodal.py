"""Honest capability gates for modalities that have not been trained yet."""
class ModalityNotReadyError(NotImplementedError):
    pass

class VisionModule:
    ready = False
    def describe_image(self, image_path: str) -> str:
        raise ModalityNotReadyError("BAKLAVAI görüntü modeli henüz eğitilmedi. Bu sürüm resim anlayamaz.")

class SpeechRecognitionModule:
    ready = False
    def transcribe(self, audio_path: str) -> str:
        raise ModalityNotReadyError("BAKLAVAI konuşma tanıma modeli henüz eğitilmedi.")

class SpeechSynthesisModule:
    ready = False
    def synthesize(self, text: str, output_path: str) -> str:
        raise ModalityNotReadyError("BAKLAVAI ses üretme modeli henüz eğitilmedi.")

# Backwards-compatible name used by the original starter.
class AudioModule(SpeechRecognitionModule, SpeechSynthesisModule):
    pass
