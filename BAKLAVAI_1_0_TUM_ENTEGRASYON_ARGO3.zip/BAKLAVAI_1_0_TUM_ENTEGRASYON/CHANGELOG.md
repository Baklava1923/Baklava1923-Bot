# Değişiklik kaydı

## 1.0.0 — Baklava1923 Bot 3.7 entegrasyonu

- Ana botun mention/reply AI sohbeti Groq üzerinden değil ortak BAKLAVAI runtime'ından geçecek şekilde bağlandı.
- `B!baklava`, `B!mod`, `B!baiargo`, `B!baisifirla`, `B!baidurumu`, `B!baieklentiler` ve `B!baiarac` komutları eklendi.
- `bot.baklavaai` üzerinden bütün yeni Discord Cog/eklentilerinin aynı runtime örneğini kullanması sağlandı.
- Salt-okunur bot durumu, komut kataloğu ve sunucu özeti araçları kaydedildi.
- Model/PyTorch bulunmadığında ana botun AI dışı komutlarını çalışır tutan isteğe bağlı bağımlılık yolu eklendi.
- Görüntü/ses yetenekleri hazırmış gibi gösterilmek yerine açıkça eğitilmemiş olarak raporlanıyor.
- Kullanıcı başına üslup/argo ve oturum geçmişi ayrımı eklendi.
- Runtime geçmiş seçimi, küçük bağlam penceresine sığacak şekilde iyileştirildi.
- Temel birim testleri 7'den 9'a çıkarıldı.

## 1.0.0 — Deneysel model çekirdeği

- Sıfırdan decoder-only Transformer, UTF-8 byte tokenizer, eğitim/doğrulama ve checkpoint altyapısı.
- Yerel terminal ve localhost HTTP istemcileri.
- Kullanıcı izniyle açılabilen yerel not hafızası.
- Açıkça çağrılan araçlar için eklenti kayıt sistemi.

## 1.0 — Argo kişiliği güncellemesi
- Varsayılan argo seviyesi 3 yapıldı.
- Seviye 3; amk, siktir, oe ve benzeri ağır gündelik küfürleri doğal ve çeşitli kullanacak şekilde açıkça tanımlandı.
- Şakalaşma ile ciddi/hassas konuşmalar ayrıldı; tehdit ve nefret söylemi sınırları korundu.
- Türkçe sokak dili örnek eğitim metni eklendi: `data/train/turkce_sokak_dili_ornekleri.txt`.
