"""Interactive BAKLAVAI terminal client."""
from __future__ import annotations
import argparse
from baklavaai.config import AppConfig
from baklavaai.runtime import BaklavaRuntime, ModelNotReadyError

HELP = """Komutlar:
  /yardim          bu listeyi göster
  /cikis           çık
  /sifirla         sohbet geçmişini temizle
  /argo 0..3       konuşma argo seviyesini ayarla
  /hatirla METİN   yerel not kaydet (BAKLAVAI_MEMORY_ENABLED=true gerekir)
  /notlar          kayıtlı notları göster
  /unut ID         bir notu sil
  /unut-hepsi      bütün yerel notları sil
  /eklentiler      kayıtlı eklentileri göster
"""


def main() -> None:
    parser = argparse.ArgumentParser(description="BAKLAVAI yerel sohbet")
    parser.add_argument("--checkpoint", default=None)
    parser.add_argument("--session", default="terminal")
    args = parser.parse_args()
    config = AppConfig.from_env()
    runtime = BaklavaRuntime(config)
    try:
        runtime.load(args.checkpoint)
    except ModelNotReadyError as exc:
        raise SystemExit(str(exc))
    print("BAKLAVAI 1.0 hazır. /yardim komutlarını kullan.")
    while True:
        try:
            text = input("Sen > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nÇıkış yapıldı.")
            break
        if not text:
            continue
        if text.lower() in {"/cikis", "/çıkış", "/exit"}:
            break
        if text == "/yardim":
            print(HELP)
        elif text == "/sifirla":
            runtime.reset_session(args.session)
            print("Sohbet geçmişi temizlendi.")
        elif text.startswith("/argo "):
            try:
                level = int(text.split(maxsplit=1)[1])
                if level not in range(4):
                    raise ValueError
                runtime.persona.argo_level = level
                print(f"Argo seviyesi: {level}")
            except ValueError:
                print("Kullanım: /argo 0, /argo 1, /argo 2 veya /argo 3")
        elif text.startswith("/hatirla "):
            if not config.memory_enabled:
                print("Hafıza kapalı. .env dosyasında BAKLAVAI_MEMORY_ENABLED=true yapmadan not saklanmaz.")
            else:
                try:
                    note_id = runtime.memory.save_note(text[len("/hatirla "):])
                    print(f"Not kaydedildi. ID: {note_id}")
                except ValueError as exc:
                    print(exc)
        elif text == "/notlar":
            if not config.memory_enabled:
                print("Hafıza kapalı.")
            else:
                notes = runtime.memory.get_notes()
                print("\n".join(f"{i} | {note} | {created}" for i, note, created in notes) or "Not yok.")
        elif text.startswith("/unut "):
            if not config.memory_enabled:
                print("Hafıza kapalı.")
            else:
                try:
                    print("Not silindi." if runtime.memory.delete_note(int(text.split(maxsplit=1)[1])) else "Bu ID bulunamadı.")
                except ValueError:
                    print("Kullanım: /unut ID")
        elif text == "/unut-hepsi":
            if config.memory_enabled:
                runtime.memory.clear()
                print("Tüm notlar silindi.")
            else:
                print("Hafıza kapalı.")
        elif text == "/eklentiler":
            print(runtime.plugins.list_plugins() or "Henüz eklenti kaydedilmedi.")
        else:
            try:
                print("BAKLAVAI >", runtime.chat(text, session_id=args.session))
            except Exception as exc:
                print(f"Çalışma hatası: {exc}")

if __name__ == "__main__":
    main()
