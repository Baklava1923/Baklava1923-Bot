"""Print a quick diagnostic without sending machine data anywhere."""
from pathlib import Path
import platform
import sys

print("BAKLAVAI sistem kontrolü")
print("Python:", sys.version.split()[0])
print("Platform:", platform.platform())
try:
    import torch
    print("PyTorch:", torch.__version__)
    print("CUDA kullanılabilir:", torch.cuda.is_available())
    if torch.cuda.is_available():
        print("GPU:", torch.cuda.get_device_name(0))
except Exception as exc:
    print("PyTorch yüklenemedi:", exc)
for item in ("data/train", "checkpoints", "checkpoints/baklavaai_latest.pt"):
    path = Path(item)
    print(f"{item}:", "VAR" if path.exists() else "YOK")
print("Not: Bu kontrol sadece yerel bilgileri ekrana yazar; hiçbir sunucuya veri göndermez.")
