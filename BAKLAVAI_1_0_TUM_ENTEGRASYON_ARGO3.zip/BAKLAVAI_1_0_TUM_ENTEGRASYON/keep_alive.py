"""Tiny HTTP health endpoint for Render-style web services; no external web framework."""
from __future__ import annotations
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread
import os

_SERVER = None
_THREAD = None

class _HealthHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        body = b"Baklava1923 Bot is running."
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        print("HEALTH", fmt % args)


def keep_alive():
    global _SERVER, _THREAD
    if _SERVER is not None:
        return
    port = int(os.getenv("PORT", "10000"))
    _SERVER = ThreadingHTTPServer(("0.0.0.0", port), _HealthHandler)
    _THREAD = Thread(target=_SERVER.serve_forever, name="baklava-health", daemon=True)
    _THREAD.start()
    print(f"Health endpoint 0.0.0.0:{port}")
