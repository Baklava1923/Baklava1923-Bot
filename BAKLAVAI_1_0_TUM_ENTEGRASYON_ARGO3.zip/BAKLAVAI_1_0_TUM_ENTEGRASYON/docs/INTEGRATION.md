# Eklentilerin ortak BAKLAVAI çekirdeğini kullanması

Ana bot başlatıldığında tek bir `DiscordBaklavaBridge` örneği yaratılır ve `bot.baklavaai` özelliğine bağlanır. Her yeni Discord Cog bu örneği kullanmalı; Cog başına yeni model yüklenmemelidir.

```python
class MyCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.ai = bot.baklavaai

    @commands.command(name="benim-ai-komutum")
    async def ask(self, ctx, *, question: str):
        async with ctx.typing():
            answer = await self.ai.achat(
                question,
                ctx.guild.id if ctx.guild else None,
                ctx.author.id,
                style="normal",
            )
        await ctx.reply(answer[:1900], mention_author=False)
```

Aynı `user_id` ve `guild_id` birleşimi, aynı kullanıcının oturumunu belirler. Her Cog aynı `bot.baklavaai` nesnesini kullanır; model, geçmiş ve persona tek yerde yönetilir.

## Araç kaydı

Eklentiler `self.ai.runtime.plugins.register(...)` ile kendi araçlarını kaydedebilir. Yalnızca gerekli alanları kabul eden ve en az yetkiyle çalışan araçlar ekle. İlk entegrasyonda listelenen araçlar salt-okunurdur. Kanal silme, rol verme, timeout, para transferi gibi yazma/yonetim araçları kullanıcı/yönetici izni ve ayrı bir onay olmadan modele açılmamalıdır.

## Önemli sınırlar

- Metin yanıtı yalnızca eğitilmiş yerel checkpoint yüklüyse üretilir.
- Görüntü ve ses modülleri henüz eğitilmedi.
- Registry kaydı, kendi başına modelin otomatik tool-calling öğrendiği anlamına gelmez. Bu sürümde araçlar açıkça Discord komutuyla çağrılır.
- Model çıktısını `eval`, `exec`, shell veya dinamik SQL olarak asla çalıştırma.
