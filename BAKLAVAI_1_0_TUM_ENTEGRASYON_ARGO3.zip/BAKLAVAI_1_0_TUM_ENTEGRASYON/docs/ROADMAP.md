# BAKLAVAI geliştirme yol haritası

## Aşama A — metin çekirdeği

- [x] Baştan başlatılan küçük Transformer
- [x] Byte tokenizer
- [x] Train/validation kaybı takibi
- [x] Checkpoint ve devam etme
- [ ] BPE tokenizer
- [ ] Büyük lisanslı veri seti ve kalite filtreleri
- [ ] GPU optimizasyonu ve daha uzun eğitim
- [ ] instruction tuning ve tercih değerlendirmesi

## Aşama B — ürün/uygulama katmanı

- [x] Ortak runtime
- [x] Terminal
- [x] HTTP API
- [x] Discord adaptörü
- [x] Eklenti registry
- [ ] Yetki kontrollü, şemalı araç seçimi
- [ ] Araç çağırma eğitim verisi ve güvenlik testleri
- [ ] İzleme, hız sınırı ve dağıtım otomasyonu

## Aşama C — görüntü

- [ ] Görüntü veri seti lisans ve kaynak kontrolü
- [ ] Vision encoder mimarisi
- [ ] Görüntü-metin eşleştirme eğitimi
- [ ] Görsel soru-cevap ve OCR değerlendirmesi

## Aşama D — ses

- [ ] Ses veri kümesi ve konuşmacı izinleri
- [ ] Konuşma tanıma
- [ ] Metinden konuşma
- [ ] Gecikme, dil ve telaffuz testleri

## Aşama E — ortak multimodal sistem

- [ ] Metin/görüntü/ses ortak temsil alanı
- [ ] Modaliteler arası instruction tuning
- [ ] Gizlilik, güvenlik, hata ve kalite değerlendirmeleri
