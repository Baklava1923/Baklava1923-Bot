"""Example: another Discord extension reusing the already-loaded BAKLAVAI core."""
from discord.ext import commands
import discord

class ExampleAIAssistant(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # Set by the bundled bot.py. Do not create a second model/runtime per Cog.
        self.ai = getattr(bot, "baklavaai", None)

    @commands.command(name="bai-ornek")
    async def example(self, ctx: commands.Context, *, text: str):
        if self.ai is None:
            return await ctx.reply("BAKLAVAI köprüsü bu botta bulunamadı.", mention_author=False)
        async with ctx.typing():
            answer = await self.ai.achat(
                text,
                ctx.guild.id if ctx.guild else None,
                ctx.author.id,
                style="normal",
            )
        await ctx.reply(
            answer[:1900], mention_author=False,
            allowed_mentions=discord.AllowedMentions.none(),
        )

async def setup(bot: commands.Bot):
    await bot.add_cog(ExampleAIAssistant(bot))
