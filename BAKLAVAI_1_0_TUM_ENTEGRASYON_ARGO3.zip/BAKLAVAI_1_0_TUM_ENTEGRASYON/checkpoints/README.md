Henüz eğitilmiş ağırlık dosyası bu pakete dahil değildir. Eğitimden sonra `baklavaai_latest.pt` otomatik oluşur. Bu dosya genellikle büyüktür ve sürüm kontrolüne eklenmemelidir.
