"""Train a small BAKLAVAI decoder-only Transformer from random initialization."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import random
import time
import torch

from baklavaai.model import BaklavaGPT, ModelConfig
from baklavaai.tokenizer import BOS, EOS, VOCAB_SIZE, encode


def load_corpus(data_dir: Path) -> tuple[torch.Tensor, list[str]]:
    files = sorted(data_dir.rglob("*.txt"))
    if not files:
        raise SystemExit(f"Eğitim metni bulunamadı: {data_dir}. UTF-8 .txt dosyaları ekle.")
    all_ids: list[int] = []
    used: list[str] = []
    seen_hashes: set[str] = set()
    for path in files:
        try:
            content = path.read_text(encoding="utf-8-sig").replace("\r\n", "\n").strip()
        except UnicodeDecodeError as exc:
            raise SystemExit(f"UTF-8 okunamadı: {path}: {exc}") from exc
        if not content:
            continue
        fingerprint = hashlib.sha256(content.encode("utf-8")).hexdigest()
        if fingerprint in seen_hashes:
            print(f"Tekrarlanan içerik atlandı: {path}")
            continue
        seen_hashes.add(fingerprint)
        all_ids.extend([BOS, *encode(content), EOS])
        used.append(str(path))
    if len(all_ids) < 256:
        raise SystemExit(f"Eğitim metni çok kısa: {len(all_ids)} byte token. Daha fazla veri ekle.")
    print(f"{len(used)} dosya | {len(all_ids):,} byte token")
    return torch.tensor(all_ids, dtype=torch.long), used


def sample_batch(tokens: torch.Tensor, batch_size: int, context: int, device: torch.device):
    starts = torch.randint(0, len(tokens) - context - 1, (batch_size,))
    x = torch.stack([tokens[int(i):int(i) + context] for i in starts]).to(device)
    y = torch.stack([tokens[int(i) + 1:int(i) + context + 1] for i in starts]).to(device)
    return x, y


@torch.no_grad()
def estimate_loss(model, train_tokens, val_tokens, batch_size, context, device, batches=8):
    model.eval()
    result = {}
    for name, source in (("train", train_tokens), ("validation", val_tokens)):
        losses = []
        for _ in range(batches):
            x, y = sample_batch(source, batch_size, context, device)
            _, loss = model(x, y)
            losses.append(float(loss.item()))
        result[name] = sum(losses) / len(losses)
    model.train()
    return result


def main():
    parser = argparse.ArgumentParser(description="BAKLAVAI 1.0 — sıfırdan küçük metin modeli eğitimi")
    parser.add_argument("--data", default="data/train")
    parser.add_argument("--steps", type=int, default=1000)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--grad-accum", type=int, default=1)
    parser.add_argument("--context", type=int, default=256)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--d-model", type=int, default=128)
    parser.add_argument("--layers", type=int, default=4)
    parser.add_argument("--heads", type=int, default=4)
    parser.add_argument("--dropout", type=float, default=0.1)
    parser.add_argument("--save-every", type=int, default=250)
    parser.add_argument("--eval-every", type=int, default=100)
    parser.add_argument("--seed", type=int, default=1923)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    for name in ("steps", "batch_size", "grad_accum", "context", "save_every", "eval_every"):
        if getattr(args, name) < 1:
            parser.error(f"--{name.replace('_', '-')} pozitif olmalı")
    if args.d_model % args.heads:
        parser.error("--d-model, --heads değerine tam bölünmeli")
    if args.device == "cuda" and not torch.cuda.is_available():
        parser.error("CUDA seçildi ama uyumlu CUDA ekran kartı/PyTorch kurulumu bulunamadı")

    random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if args.device == "cuda" or (args.device == "auto" and torch.cuda.is_available()) else "cpu")
    print(f"Cihaz: {device}. Bu deneysel küçük bir model; büyük asistan kalitesi bekleme.")
    tokens, source_files = load_corpus(Path(args.data))
    split = max(args.context + 2, int(len(tokens) * 0.9))
    split = min(split, len(tokens) - 1)
    train_tokens, val_tokens = tokens[:split], tokens[split:]
    if len(train_tokens) <= args.context + 1 or len(val_tokens) <= args.context + 1:
        raise SystemExit("Eğitim/doğrulama verisi bu context için yetersiz. Daha fazla .txt ekle veya --context değerini düşür.")

    config = ModelConfig(vocab_size=VOCAB_SIZE, context_length=args.context, d_model=args.d_model,
                         n_heads=args.heads, n_layers=args.layers, dropout=args.dropout)
    model = BaklavaGPT(config).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate)
    start_step = 0
    checkpoint_dir = Path("checkpoints")
    checkpoint_dir.mkdir(exist_ok=True)
    output = checkpoint_dir / "baklavaai_latest.pt"
    if args.resume and output.exists():
        checkpoint = torch.load(output, map_location=device, weights_only=True)
        if checkpoint["config"] != model.config_dict():
            raise SystemExit("Checkpoint ayarları bu eğitim ayarlarıyla aynı değil. Eski modeli yedekle veya aynı ayarlarla başlat.")
        model.load_state_dict(checkpoint["model_state"])
        if "optimizer_state" in checkpoint:
            optimizer.load_state_dict(checkpoint["optimizer_state"])
        start_step = int(checkpoint.get("step", 0))
        print(f"Eğitime {start_step}. adımdan devam ediliyor")

    print(f"Parametre: {model.parameter_count():,} | Eğitim tokenı: {len(train_tokens):,} | Doğrulama: {len(val_tokens):,}")
    model.train()
    started = time.time()
    history = []
    for step in range(start_step + 1, start_step + args.steps + 1):
        optimizer.zero_grad(set_to_none=True)
        total_loss = 0.0
        for _ in range(args.grad_accum):
            x, y = sample_batch(train_tokens, args.batch_size, args.context, device)
            _, loss = model(x, y)
            (loss / args.grad_accum).backward()
            total_loss += float(loss.item()) / args.grad_accum
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        if step == 1 or step % 25 == 0:
            print(f"adım {step:>6} | eğitim loss {total_loss:.4f}")
        if step % args.eval_every == 0 or step == start_step + args.steps:
            metrics = estimate_loss(model, train_tokens, val_tokens, args.batch_size, args.context, device)
            history.append({"step": step, **metrics})
            print(f"değerlendirme | train {metrics['train']:.4f} | val {metrics['validation']:.4f}")
        if step % args.save_every == 0 or step == start_step + args.steps:
            torch.save({"model_state": model.state_dict(), "optimizer_state": optimizer.state_dict(),
                        "config": model.config_dict(), "step": step,
                        "source_files": source_files, "seed": args.seed,
                        "saved_at_unix": int(time.time())}, output)
            print(f"Kaydedildi: {output}")
    metrics_path = checkpoint_dir / "training_metrics.json"
    metrics_path.write_text(json.dumps({"history": history, "elapsed_seconds": round(time.time() - started, 2)},
                                       ensure_ascii=False, indent=2), encoding="utf-8")
    print("Eğitim deneyi bitti. ChatGPT düzeyinde bir sistem oluştuğu anlamına gelmez.")

if __name__ == "__main__":
    main()
