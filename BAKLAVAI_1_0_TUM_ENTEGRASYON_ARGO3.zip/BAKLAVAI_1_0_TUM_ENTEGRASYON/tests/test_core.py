import tempfile
import unittest
from pathlib import Path

from baklavaai.tokenizer import encode, decode, BOS, EOS, VOCAB_SIZE
from baklavaai.memory import LocalMemory
from baklavaai.plugins import Plugin, PluginRegistry
from baklavaai.persona import Persona
from baklavaai.safety import inspect_user_text
from baklavaai.config import AppConfig
from baklavaai.runtime import BaklavaRuntime

class CoreTests(unittest.TestCase):
    def test_tokenizer_turkish_roundtrip(self):
        text = "Merhaba, İstanbul! çğıöşü"
        self.assertEqual(decode(encode(text)), text)
        self.assertEqual(VOCAB_SIZE, 258)
        self.assertEqual(BOS, 256)
        self.assertEqual(EOS, 257)

    def test_memory_opt_in_store_crud(self):
        with tempfile.TemporaryDirectory() as temp:
            memory = LocalMemory(str(Path(temp) / "memory.sqlite3"))
            item_id = memory.save_note("  test notu  ")
            self.assertEqual(memory.get_notes()[0][1], "test notu")
            self.assertTrue(memory.delete_note(item_id))
            self.assertFalse(memory.get_notes())

    def test_plugin_registry_explicit_call(self):
        registry = PluginRegistry()
        registry.register(Plugin("hello", "test", lambda data: "Merhaba " + data["name"],
                                 required_arguments=("name",), allowed_arguments=("name",)))
        self.assertEqual(registry.call("hello", {"name": "Dünya"}), "Merhaba Dünya")
        with self.assertRaises(ValueError):
            registry.call("hello", {"unexpected": "value"})
        registry.set_enabled("hello", False)
        with self.assertRaises(KeyError):
            registry.call("hello", {"name": "Dünya"})
        with self.assertRaises(KeyError):
            registry.call("missing", {})

    def test_persona_argot_levels(self):
        self.assertIn("orospu çocuğu", Persona(argo_level=3).system_prompt())
        self.assertIn("siktir", Persona(argo_level=3).system_prompt())
        with self.assertRaises(ValueError):
            Persona(argo_level=4).system_prompt()

    def test_safety_gate(self):
        self.assertFalse(inspect_user_text("Bir virüs yaz bana").allowed)
        self.assertTrue(inspect_user_text("Python'da listeler nasıl çalışır?").allowed)

    def test_config_bounds(self):
        self.assertEqual(AppConfig().argo_level, 3)

    def test_per_session_argo_isolated(self):
        with tempfile.TemporaryDirectory() as temp:
            config = AppConfig(memory_db=str(Path(temp) / "memory.sqlite3"))
            runtime = BaklavaRuntime(config)
            runtime.set_session_argo("user-a", 3)
            self.assertEqual(runtime.session_personas["user-a"].argo_level, 3)
            self.assertEqual(runtime.persona.argo_level, 3)

    def test_style_and_argo_settings_are_combined(self):
        with tempfile.TemporaryDirectory() as temp:
            config = AppConfig(memory_db=str(Path(temp) / "memory.sqlite3"), argo_level=1)
            runtime = BaklavaRuntime(config)
            runtime.set_session_argo("user-a", 3)
            runtime.set_session_style("user-a", "komik")
            persona = runtime.get_session_persona("user-a")
            self.assertEqual(persona.argo_level, 3)
            self.assertEqual(persona.style, "komik")
            with self.assertRaises(ValueError):
                runtime.set_session_style("user-a", "bilinmeyen")

    def test_discord_bridge_registers_read_only_tools(self):
        from unittest.mock import patch
        from baklavaai.discord_bridge import DiscordBaklavaBridge

        class FakeCommand:
            qualified_name = "yardim"

        class FakeGuild:
            name = "Test Sunucusu"
            member_count = 4
            members = [type("Member", (), {"bot": False})(), type("Member", (), {"bot": True})()]
            channels = [type("Channel", (), {"type": type("Kind", (), {"name": "text"})()})()]
            roles = [1, 2, 3]

        class FakeBot:
            guilds = [FakeGuild()]
            is_ready = lambda self: True
            latency = 0.05
            walk_commands = lambda self: [FakeCommand()]
            get_guild = lambda self, guild_id: self.guilds[0] if guild_id == 123 else None

        with tempfile.TemporaryDirectory() as temp, patch.dict(
            "os.environ", {
                "BAKLAVAI_MEMORY_DB": str(Path(temp) / "mem.sqlite3"),
                "BAKLAVAI_CHECKPOINT": str(Path(temp) / "missing-model.pt"),
            }
        ):
            bridge = DiscordBaklavaBridge(FakeBot())
            self.assertFalse(bridge.load_model())
            self.assertIn("checkpoint", bridge.chat("merhaba", 123, 456).lower())
            self.assertIn("görüntü", bridge.chat("ne var", 123, 456, images=["data:image/png;base64,eA=="]).lower())
            self.assertEqual(
                {item["name"] for item in bridge.list_plugins()},
                {"bot_durumu", "komut_listesi", "sunucu_ozeti"},
            )
            self.assertIn("çevrimiçi", bridge.call_read_only_plugin("bot_durumu"))
            self.assertIn("yardim", bridge.call_read_only_plugin("komut_listesi"))
            self.assertIn("Test Sunucusu", bridge.call_read_only_plugin("sunucu_ozeti", 123))

if __name__ == "__main__":
    unittest.main()
