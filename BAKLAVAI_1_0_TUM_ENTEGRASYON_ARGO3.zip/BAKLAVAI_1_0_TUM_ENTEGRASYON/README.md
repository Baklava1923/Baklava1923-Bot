# Baklava1923 Bot 3.7 + BAKLAVAI 1.0

Bu paket, mevcut Baklava1923 Discord botunun komutlarını ve veritabanı akışını korurken yapay zekâ tarafını tek bir yerel BAKLAVAI çekirdeğine bağlayan entegrasyon sürümüdür.

## Ne değişti?

- Botun etiketlenerek / yanıt verilerek açılan sohbeti artık BAKLAVAI ortak runtime'ına gider.
- `B!baklava <mesaj>` (`B!bai`) aynı çekirdeğe doğrudan erişir.
- `B!mod <mod>` kullanıcıya özel üslup seçer: `normal`, `komik`, `ciddi`, `korkutucu`, `tartismaci`.
- `B!baiargo 0-3` kullanıcıya özel argo seviyesini ayarlar. Seviye 3 daha sert gündelik argo talimatıdır; tehdit, nefret veya hedefli taciz üretme özelliği değildir.
- `B!baisifirla` kullanıcının o sunucudaki sohbet bağlamını temizler.
- `B!baidurumu` model, cihaz, parametre sayısı, hafıza ve modül durumunu gösterir.
- `B!baieklentiler` ve `B!baiarac <araç>` ortak kayıt sistemindeki salt-okunur araçları listeler/çağırır.
- Görsel/ses modülleri henüz eğitilmediği için bot bunları anladığını iddia etmez.
- Groq/OpenAI API çağrısı ve API anahtarı zorunluluğu kaldırılmıştır. Otomatik harici API yedeği yoktur.
- Model/PyTorch bulunmasa bile botun ekonomi, moderasyon, oyun ve sunucu yönetimi komutları açılmaya devam eder.

## Önemli sınır

Bu sürüm, kendi ağırlıklarını sıfırdan eğitebilen küçük ve deneysel bir Transformer içerir. Hazır büyük bir dil modeli değildir. Henüz eğitilmiş checkpoint yoksa AI sohbeti anlamlı cevap veremez. Görüntü, ses tanıma, ses üretimi, otomatik internet araştırması ve güvenilir otomatik araç planlama bu sürümde tamamlanmış değildir. Var olan her Discord komutu da otomatik olarak AI tarafından çalıştırılmaz: yönetim ve ekonomi komutları kendi yetki kontrollerinde kalır. Ortak çekirdeğe yalnızca güvenli salt-okunur araçlar kaydedilmiştir.

## Windows 11 kurulumu

1. Python 3.11 veya üstünü kur.
2. Bu klasörde terminal aç.
3. Sanal ortam kur ve etkinleştir:

```bat
py -m venv .venv
.venv\Scripts\activate
```

4. Botun temel bağımlılıklarını kur:

```bat
python -m pip install -r requirements.txt
```

5. BAKLAVAI modelini eğitmek/yüklemek için PyTorch da kur:

```bat
python -m pip install -r requirements-baklavaai.txt
```

6. `.env.example` değerlerini Windows ortam değişkenleri olarak ekle. Gerçek Discord token'ını asla GitHub'a yükleme.
7. Kod testlerini çalıştır:

```bat
python -m unittest discover -s tests -v
```

## Eğitim verisi

Yalnızca kullanma iznin olan ve kişisel veri içermeyen Türkçe metinleri `data/raw/` içine UTF-8 `.txt` olarak koy. Şifre, token, özel mesaj, adres, telefon, okul kaydı veya başkasına ait özel konuşmaları eğitim verisine ekleme. Web'de okunabiliyor olması, bir metnin model eğitimi için otomatik olarak izinli olduğu anlamına gelmez.

Veriyi temizleyip eğitim klasörüne hazırla:

```bat
python scripts\prepare_dataset.py --source data\raw --output data\train
```

İlk küçük donanım denemesi:

```bat
python train.py --steps 100 --batch-size 2 --context 128 --d-model 64 --layers 2 --heads 2 --save-every 50 --eval-every 25
```

Eğitim sonucu `checkpoints/baklavaai_latest.pt` dosyasıdır. Bu sadece küçük bir test modelidir ve kuvvetli sohbet kalitesi beklenmemelidir. Daha fazla adım, daha iyi veri ve güçlü GPU gerekir.

## Discord botunu çalıştırma

Aynı klasörde `DISCORD_TOKEN` ortam değişkeni ayarlı olmalı. Ardından:

```bat
python bot.py
```

Bot açılırken checkpoint'i yüklemeyi dener. Dosya yoksa bu durum log'a yazılır; botun AI dışındaki komutları çalışmayı sürdürür. Modelin Render üzerinde çevrimiçi sohbet verebilmesi için `torch` bağımlılığı ve checkpoint dosyası da Render dağıtımında bulunmalıdır. Render'ın ücretsiz disk/RAM sınırları küçük CPU modelini bile kısıtlayabilir; büyük model eğitimi Render üzerinde yapılmamalıdır.

## AI komutları

| Komut | İşlev |
|---|---|
| `B!baklava <mesaj>` | Aynı yerel çekirdekle sohbet |
| Botu etiketle / bot mesajına yanıt ver | Sohbet |
| `B!mod <mod>` | Kullanıcıya özel üslup |
| `B!baiargo 0-3` | Kullanıcıya özel argo düzeyi |
| `B!baisifirla` | O sunucudaki sohbet geçmişini temizle |
| `B!baidurumu` | Model ve modül durumunu göster |
| `B!baieklentiler` | Kayıtlı araçları listeler |
| `B!baiarac bot_durumu` | Bot sağlık bilgisi |
| `B!baiarac komut_listesi` | Kayıtlı komut adları |
| `B!baiarac sunucu_ozeti` | Geçerli sunucunun temel sayımları |
| `B!yapayzeka` | AI yardım menüsü |

## Güvenlik ve eklentiler

- Ortak runtime tüm AI metin sohbetinin tek geçiş noktasıdır.
- Eklenti kayıt sistemi, isim/izin verilen argüman kontrolleri uygular.
- İlk Discord entegrasyonunda salt-okunur araçlar vardır. Modelden gelen metin hiçbir zaman `eval`, `exec`, shell veya Discord yönetim komutu olarak çalıştırılmaz.
- Ban, timeout, rol, kanal, ekonomi transferi, silme gibi değişiklik yapan eylemler mevcut Discord komutlarının kendi izin ve onay akışında kalır.
- Sohbet bağlamı RAM'de tutulur; bot yeniden başladığında silinir. Kalıcı not hafızası varsayılan olarak kapalıdır.
- `keep_alive.py`, Render için basit bir health endpoint açar. Gerçek bot token'ı yalnızca Environment değişkeninde saklanır.

## Paket yapısı

```text
bot.py                         mevcut botun 3.7 entegre sürümü
keep_alive.py                  web health endpoint
baklavaai/runtime.py            ortak yerel model runtime'ı
baklavaai/discord_bridge.py     ana bot ile köprü
baklavaai/model.py              sıfırdan Transformer
baklavaai/tokenizer.py          UTF-8 byte tokenizer
baklavaai/persona.py            mod ve argo ayarları
baklavaai/plugins.py            izinli araç kayıt sistemi
baklavaai/multimodal.py         henüz eğitilmemiş görüntü/ses kapıları
train.py                        eğitim
chat.py                         terminal istemcisi
server.py                       yerel HTTP API
```

### Argo kişiliği
Varsayılan argo seviyesi artık 3'tür. Discord'da `B!baiargo 3` komutuyla ağır gündelik argo modu seçilebilir; `0` kapatır. Örnek Türkçe diyaloglar `data/train/turkce_sokak_dili_ornekleri.txt` içindedir. Bunlar modelin öğrenmesi için eğitim verisidir; eğitim yapılmadan küçük rastgele başlangıç modeli bu üslubu güvenilir biçimde uygulayamaz.
