"""Static and SQLite schema smoke checks for Baklava1923 Bot 3.6.2 MEGA."""

from __future__ import annotations

import ast
import collections
import pathlib
import sqlite3
import sys

ROOT = pathlib.Path(__file__).resolve().parent
PY_FILES = [ROOT / "bot.py", ROOT / "baklava_mega.py", ROOT / "keep_alive.py"]


def collect_commands(path: pathlib.Path) -> list[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    names: list[str] = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        for decorator in node.decorator_list:
            if not isinstance(decorator, ast.Call):
                continue
            if not isinstance(decorator.func, ast.Attribute) or decorator.func.attr != "command":
                continue
            owner = decorator.func.value
            if not isinstance(owner, ast.Name) or owner.id not in {"bot", "commands"}:
                continue
            name = node.name
            aliases: list[str] = []
            for keyword in decorator.keywords:
                if keyword.arg == "name" and isinstance(keyword.value, ast.Constant):
                    name = str(keyword.value.value)
                elif keyword.arg == "aliases" and isinstance(keyword.value, (ast.Tuple, ast.List)):
                    aliases = [str(item.value) for item in keyword.value.elts if isinstance(item, ast.Constant)]
            names.extend([name, *aliases])
    return names


def test_schema() -> int:
    source = (ROOT / "baklava_mega.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    sql = None
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == "_create_tables":
            for child in ast.walk(node):
                if isinstance(child, ast.Call) and isinstance(child.func, ast.Attribute) and child.func.attr == "executescript":
                    if child.args and isinstance(child.args[0], ast.Constant):
                        sql = child.args[0].value
                        break
    if not sql:
        raise AssertionError("MEGA SQLite schema not found")
    connection = sqlite3.connect(":memory:")
    connection.execute(
        "CREATE TABLE economy(guild_id INTEGER,user_id INTEGER,balance INTEGER DEFAULT 1000,PRIMARY KEY(guild_id,user_id))"
    )
    connection.executescript(sql)
    tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    required = {
        "mega_daily", "mega_profiles", "mega_reputation", "mega_inventory",
        "mega_clubs", "mega_club_members", "mega_guild_config", "mega_filter_words",
        "mega_market_listings", "mega_events", "mega_event_members", "mega_voice_sessions",
    }
    missing = required - tables
    if missing:
        raise AssertionError(f"Missing MEGA tables: {sorted(missing)}")
    connection.close()
    return len(tables)


def main() -> int:
    for path in PY_FILES:
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    all_names: list[str] = []
    for path in PY_FILES[:2]:
        all_names.extend(collect_commands(path))
    counts = collections.Counter(name.casefold() for name in all_names)
    duplicates = sorted(name for name, count in counts.items() if count > 1)
    if duplicates:
        raise AssertionError(f"Duplicate command names or aliases: {duplicates}")
    bot_source = (ROOT / "bot.py").read_text(encoding="utf-8")
    if 'await bot.load_extension("baklava_mega")' not in bot_source:
        raise AssertionError("MEGA extension startup hook is missing")
    table_count = test_schema()
    print("Python AST syntax: PASS")
    print(f"Prefix commands and aliases: {len(all_names)} unique, no collisions")
    print(f"MEGA schema: PASS ({table_count} total tables including SQLite system tables)")
    print("Extension startup hook: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
