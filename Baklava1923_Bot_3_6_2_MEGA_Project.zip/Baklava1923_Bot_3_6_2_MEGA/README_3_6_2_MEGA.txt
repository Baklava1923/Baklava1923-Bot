BAKLAVA1923 BOT 3.6.2 MEGA
===========================

FILES
-----
bot.py              Main bot. Existing 3.6.2 Ultimate systems are preserved.
baklava_mega.py     Additive MEGA Cog with new systems and commands.
keep_alive.py       Standard-library health endpoint used by Render.
requirements.txt    Runtime dependencies.

RENDER SETTINGS
---------------
Start Command: python bot.py

Required environment variable:
DISCORD_TOKEN = your Discord bot token

Optional but recommended:
GROQ_API_KEY = existing Baklavai AI key; without it, AI answers are disabled.
BOT_DATA_GITHUB_TOKEN = GitHub fine-grained token with Contents read/write.
BOT_DATA_GITHUB_REPO = Baklava1923/Baklava1923-Bot
BOT_DATA_GITHUB_PATH = bot_data.json

Do not put tokens in bot.py, GitHub commits, screenshots, or chat messages.

GITHUB BACKUP NOTES
-------------------
The main file restores aktiflik.db from bot_data.json only if the local database
file is missing or empty. The existing database is never overwritten when a
non-empty local DB already exists. Periodic backups run every 5 minutes when a
GitHub token is configured. A recent backup should be checked before replacing
an existing Render deployment. This is not a substitute for keeping an offline
copy of the database.

COMMAND PREFIXES
----------------
!, B!, b!
New systems are documented with B!mega-yardim.

NEW MEGA SYSTEMS
----------------
- daily and weekly bonuses with streak tracking
- safe player-to-player currency transfers
- profile biographies, titles, reputation and badges
- collection shop, collection inventory, resale and crafting
- player-to-player marketplace with escrowed inventory and transactional buys
- guild clubs, club banks, contributions, leadership transfer and rankings
- server-wide contribution goals with proportional reward distribution
- self-service role panels restricted to configured low-privilege roles
- welcome channel, moderation log, word/invite/spam filters
- suggestion intake and moderator approval/rejection
- upcoming server events and attendee registration
- math, trivia, word-scramble and riddle minigames
- daily activity statistics and quest tracking/rewards
- user, channel, role, avatar, banner and server cards
- safe arithmetic calculator (AST evaluator; no eval execution)

IMPORTANT LIMITS
----------------
- No live Discord connection or real server action was tested in this environment.
- Python syntax, AST command-name collisions and project packaging are checked.
- The Discord Developer Portal must have Message Content and Server Members
  intents enabled for the features that depend on those events.
- Invite the bot with only the permissions it needs. For moderation, role
  management and logging, set its role above only the roles it should manage.
- A free Render filesystem is ephemeral. The GitHub backup is only active after
  both Render environment variables are added and a first successful upload is
  visible in the repository.
