"""Tiny standard-library health server for Render deployments."""

import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class HealthHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path not in ("/", "/health", "/healthz"):
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"not found")
            return
        body = b"Baklava1923 Bot is running"
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        return


def keep_alive():
    """Start a non-blocking health endpoint once per Python process."""
    if getattr(keep_alive, "_started", False):
        return
    port = int(os.getenv("PORT", "10000"))
    server = ThreadingHTTPServer(("0.0.0.0", port), HealthHandler)
    thread = threading.Thread(target=server.serve_forever, name="baklava-health", daemon=True)
    thread.start()
    keep_alive._server = server
    keep_alive._started = True
    print(f"Health server listening on 0.0.0.0:{port}")
