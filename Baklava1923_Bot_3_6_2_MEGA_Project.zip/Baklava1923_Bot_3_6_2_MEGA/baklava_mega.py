from __future__ import annotations

import ast
import asyncio
import json
import math
import os
import random
import re
import sqlite3
import string
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable, Optional

import discord
from discord.ext import commands


# Baklava1923 Bot 3.6.2 MEGA expansion
# This module is an additive Cog. It uses a separate set of tables and does not
# alter or rename the original bot's economy, marriage, fishing, ticket or raid tables.

DB_PATH = os.getenv(
    "DATABASE_PATH",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "aktiflik.db"),
)
OWNER_ID = int(os.getenv("BOT_OWNER_ID", "1358430002508726276"))
PREFIXES = ("!", "B!", "b!")
INVITE_PATTERN = re.compile(
    r"(?:https?://)?(?:www\.)?(?:discord\.gg|discord(?:app)?\.com/invite)/[A-Za-z0-9-]+",
    re.IGNORECASE,
)

DAILY_REWARDS = (250, 300, 350, 400, 450, 500, 750)
WEEKLY_REWARD = 1800
MAX_BIO_LENGTH = 160
MAX_CLUB_NAME = 28
MAX_CLUB_DESCRIPTION = 120
MAX_FILTER_WORD_LENGTH = 40
MAX_SELF_ROLES = 20

TRIVIA_QUESTIONS = [
    ("Türkiye'nin başkenti neresidir", "ankara", "Ankara"),
    ("Güneş sistemindeki en büyük gezegen hangisidir", "jupiter", "Jüpiter"),
    ("Bir yılda kaç ay vardır", "12", "12"),
    ("Su hangi sıcaklıkta donar (Celsius)", "0", "0 derece"),
    ("Python dilinde liste hangi köşeli işaretlerle yazılır", "[]", "Köşeli parantez"),
    ("Dünyanın doğal uydusunun adı nedir", "ay", "Ay"),
    ("Türkiye'nin en büyük gölü hangisidir", "van golu", "Van Gölü"),
    ("Bir üçgenin iç açıları toplamı kaç derecedir", "180", "180 derece"),
    ("Bitkiler fotosentez sırasında hangi gazı alır", "karbondioksit", "Karbondioksit"),
    ("İstiklal Marşı'nın yazarı kimdir", "mehmet akif ersoy", "Mehmet Akif Ersoy"),
    ("Dünya hangi yıldızın etrafında döner", "gunes", "Güneş"),
    ("Bir kilometre kaç metredir", "1000", "1000 metre"),
    ("Türkiye hangi iki kıta üzerinde toprak sahibidir", "asya avrupa", "Asya ve Avrupa"),
    ("İnsan vücudunda kanı pompalayan organ hangisidir", "kalp", "Kalp"),
    ("En küçük asal sayı kaçtır", "2", "2"),
    ("Türk alfabesinde kaç harf vardır", "29", "29"),
    ("Dünya'nın şekline en yakın geometrik şekil nedir", "geoit", "Geoit"),
    ("Bir saatte kaç dakika vardır", "60", "60"),
    ("Işığın boşluktaki hızı yaklaşık kaç km/s'dir", "300000", "300 bin km/s"),
    ("Kızıl gezegen olarak bilinen gezegen hangisidir", "mars", "Mars"),
    ("İnsan vücudundaki en büyük organ hangisidir", "deri", "Deri"),
    ("Dünya'nın en büyük okyanusu hangisidir", "pasifik", "Pasifik Okyanusu"),
    ("Bir dik açının ölçüsü kaç derecedir", "90", "90 derece"),
    ("Türkiye'nin para birimi nedir", "turk lirasi", "Türk lirası"),
    ("Elektrik akımının birimi nedir", "amper", "Amper"),
]

WORD_BANK = [
    "baklava", "bilgisayar", "gezegen", "macera", "sunucu", "oyuncu", "kitap",
    "deniz", "orman", "yildiz", "kutuphane", "pencere", "muzik", "astronomi",
    "matematik", "yazilim", "robot", "bulut", "bisiklet", "kalem", "laboratuvar",
    "mikroskop", "gezgin", "harita", "arkadaslik", "enerji", "tasarim", "kodlama",
]

SHOP_CATALOG = {
    "baklava_kutusu": {"name": "Baklava Kutusu", "price": 900, "description": "Profilinde sergileyebileceğin koleksiyon kutusu", "category": "koleksiyon"},
    "altin_kasik": {"name": "Altın Kaşık", "price": 2200, "description": "Parlak bir koleksiyon eşyası", "category": "koleksiyon"},
    "minik_rozet": {"name": "Minik Rozet", "price": 500, "description": "Başlangıç koleksiyon rozeti", "category": "rozet"},
    "yildiz_rozet": {"name": "Yıldız Rozeti", "price": 3500, "description": "Görevlerle kazanılan özel görünüm", "category": "rozet"},
    "profil_cercevesi": {"name": "Baklava Çerçevesi", "price": 1800, "description": "Profil kartı koleksiyon çerçevesi", "category": "kozmetik"},
    "renkli_unvan": {"name": "Renkli Unvan", "price": 2600, "description": "Koleksiyon vitrininde gösterilen unvan", "category": "kozmetik"},
    "not_defteri": {"name": "Not Defteri", "price": 300, "description": "Koleksiyon rafına eklenen eşya", "category": "koleksiyon"},
    "dijital_anahtar": {"name": "Dijital Anahtar", "price": 1200, "description": "Koleksiyon anahtarı", "category": "koleksiyon"},
    "mini_heykel": {"name": "Mini Heykel", "price": 4200, "description": "Nadir koleksiyon parçası", "category": "koleksiyon"},
    "baklava_taci": {"name": "Baklava Tacı", "price": 10000, "description": "En pahalı koleksiyon unvanı", "category": "kozmetik"},
}

DAILY_QUESTS = {
    "chat_10": {"title": "Sohbet Isınması", "description": "10 mesaj gönder", "target": 10, "reward": 180, "kind": "message"},
    "chat_30": {"title": "Sohbet Ustası", "description": "30 mesaj gönder", "target": 30, "reward": 420, "kind": "message"},
    "command_5": {"title": "Komut Kaşifi", "description": "5 bot komutu kullan", "target": 5, "reward": 250, "kind": "command"},
    "voice_15": {"title": "Sesli Takılan", "description": "15 dakika ses kanalında kal", "target": 15, "reward": 300, "kind": "voice"},
    "help_1": {"title": "Topluluk Desteği", "description": "Bir öneri paylaş", "target": 1, "reward": 200, "kind": "suggestion"},
}


class EmbedPager(discord.ui.View):
    """Small reusable paginator for the command and leaderboard panels."""

    def __init__(self, pages: list[discord.Embed], owner_id: int, timeout: float = 90):
        super().__init__(timeout=timeout)
        self.pages = pages
        self.owner_id = owner_id
        self.index = 0
        self._sync_buttons()

    def _sync_buttons(self) -> None:
        self.previous.disabled = self.index <= 0
        self.next.disabled = self.index >= len(self.pages) - 1

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Bu menüyü yalnızca açan kişi kullanabilir", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Önceki", style=discord.ButtonStyle.secondary, emoji="◀")
    async def previous(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.index = max(0, self.index - 1)
        self._sync_buttons()
        await interaction.response.edit_message(embed=self.pages[self.index], view=self)

    @discord.ui.button(label="Sonraki", style=discord.ButtonStyle.primary, emoji="▶")
    async def next(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.index = min(len(self.pages) - 1, self.index + 1)
        self._sync_buttons()
        await interaction.response.edit_message(embed=self.pages[self.index], view=self)

    async def on_timeout(self) -> None:
        for child in self.children:
            if isinstance(child, discord.ui.Button):
                child.disabled = True


class MathChallengeView(discord.ui.View):
    def __init__(self, owner_id: int, answer: int, reward_callback, timeout: float = 45):
        super().__init__(timeout=timeout)
        self.owner_id = owner_id
        self.answer = answer
        self.reward_callback = reward_callback
        self.finished = False

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Bu soru başka bir oyuncu için hazırlanmış", ephemeral=True)
            return False
        if self.finished:
            await interaction.response.send_message("Bu soru zaten tamamlandı", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Cevabı yaz", style=discord.ButtonStyle.primary)
    async def answer_button(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.send_modal(MathAnswerModal(self))

    async def finish(self, interaction: discord.Interaction, correct: bool) -> None:
        self.finished = True
        for child in self.children:
            if isinstance(child, discord.ui.Button):
                child.disabled = True
        if correct:
            self.reward_callback()
            await interaction.response.edit_message(content="Doğru cevap tebrikler 150 puan kazandın", view=self)
        else:
            await interaction.response.edit_message(content="Bu kez olmadı doğru cevap farklıydı", view=self)


class MathAnswerModal(discord.ui.Modal, title="Matematik sorusu"):
    answer = discord.ui.TextInput(label="Cevabın", max_length=12, required=True)

    def __init__(self, parent_view: MathChallengeView):
        super().__init__()
        self.parent_view = parent_view

    async def on_submit(self, interaction: discord.Interaction) -> None:
        raw = str(self.answer.value).strip().replace(" ", "")
        correct = bool(re.fullmatch(r"-?\d+", raw)) and int(raw) == self.parent_view.answer
        await self.parent_view.finish(interaction, correct)


class BaklavaMega(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        os.makedirs(os.path.dirname(os.path.abspath(DB_PATH)), exist_ok=True)
        self.db = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA busy_timeout=30000")
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db_lock = asyncio.Lock()
        self.spam_cache: dict[tuple[int, int], deque[float]] = defaultdict(deque)
        self.quiz_sessions: dict[tuple[int, int], tuple[str, str, float]] = {}
        self.word_sessions: dict[tuple[int, int], tuple[str, str, float]] = {}
        self._create_tables()

    def cog_unload(self) -> None:
        try:
            self.db.commit()
            self.db.close()
        except Exception:
            pass

    def _create_tables(self) -> None:
        self.db.executescript(
            """
            CREATE TABLE IF NOT EXISTS mega_daily (
                guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
                last_claim TEXT, streak INTEGER NOT NULL DEFAULT 0,
                weekly_claim TEXT, PRIMARY KEY(guild_id,user_id)
            );
            CREATE TABLE IF NOT EXISTS mega_profiles (
                guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
                bio TEXT NOT NULL DEFAULT '', favorite_color TEXT NOT NULL DEFAULT 'default',
                profile_title TEXT NOT NULL DEFAULT '', updated_at REAL NOT NULL DEFAULT 0,
                PRIMARY KEY(guild_id,user_id)
            );
            CREATE TABLE IF NOT EXISTS mega_reputation (
                guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
                points INTEGER NOT NULL DEFAULT 0, last_given REAL NOT NULL DEFAULT 0,
                PRIMARY KEY(guild_id,user_id)
            );
            CREATE TABLE IF NOT EXISTS mega_rep_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL,
                giver_id INTEGER NOT NULL, receiver_id INTEGER NOT NULL,
                created_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS mega_inventory (
                guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
                item_key TEXT NOT NULL, quantity INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY(guild_id,user_id,item_key)
            );
            CREATE TABLE IF NOT EXISTS mega_quests (
                guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
                quest_key TEXT NOT NULL, quest_date TEXT NOT NULL,
                progress INTEGER NOT NULL DEFAULT 0, claimed INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY(guild_id,user_id,quest_key,quest_date)
            );
            CREATE TABLE IF NOT EXISTS mega_clubs (
                id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL,
                name TEXT NOT NULL, slug TEXT NOT NULL, description TEXT NOT NULL,
                owner_id INTEGER NOT NULL, bank INTEGER NOT NULL DEFAULT 0,
                created_at REAL NOT NULL, UNIQUE(guild_id,slug)
            );
            CREATE TABLE IF NOT EXISTS mega_club_members (
                guild_id INTEGER NOT NULL, club_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL, joined_at REAL NOT NULL,
                role TEXT NOT NULL DEFAULT 'member', contribution INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY(guild_id,user_id)
            );
            CREATE TABLE IF NOT EXISTS mega_guild_config (
                guild_id INTEGER PRIMARY KEY,
                welcome_channel_id INTEGER, modlog_channel_id INTEGER,
                invite_filter INTEGER NOT NULL DEFAULT 0,
                spam_filter INTEGER NOT NULL DEFAULT 0,
                spam_limit INTEGER NOT NULL DEFAULT 6,
                spam_window INTEGER NOT NULL DEFAULT 8,
                word_filter INTEGER NOT NULL DEFAULT 0,
                suggestions_channel_id INTEGER
            );
            CREATE TABLE IF NOT EXISTS mega_filter_words (
                guild_id INTEGER NOT NULL, word TEXT NOT NULL,
                added_by INTEGER NOT NULL, created_at REAL NOT NULL,
                PRIMARY KEY(guild_id,word)
            );
            CREATE TABLE IF NOT EXISTS mega_modlog (
                id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL,
                actor_id INTEGER, target_id INTEGER, action TEXT NOT NULL,
                reason TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS mega_self_roles (
                guild_id INTEGER NOT NULL, role_id INTEGER NOT NULL,
                added_by INTEGER NOT NULL, created_at REAL NOT NULL,
                PRIMARY KEY(guild_id,role_id)
            );
            CREATE TABLE IF NOT EXISTS mega_suggestions (
                id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL, message_id INTEGER, channel_id INTEGER,
                text TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
                moderator_id INTEGER, created_at REAL NOT NULL, updated_at REAL
            );
            CREATE TABLE IF NOT EXISTS mega_message_stats (
                guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
                stat_date TEXT NOT NULL, message_count INTEGER NOT NULL DEFAULT 0,
                command_count INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY(guild_id,user_id,stat_date)
            );
            CREATE TABLE IF NOT EXISTS mega_badges (
                guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
                badge_key TEXT NOT NULL, earned_at REAL NOT NULL,
                PRIMARY KEY(guild_id,user_id,badge_key)
            );
            CREATE TABLE IF NOT EXISTS mega_goals (
                id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL,
                owner_id INTEGER NOT NULL, title TEXT NOT NULL, target INTEGER NOT NULL,
                current INTEGER NOT NULL DEFAULT 0, reward INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'open', created_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS mega_goal_members (
                goal_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
                contribution INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY(goal_id,user_id)
            );
            CREATE TABLE IF NOT EXISTS mega_role_panels (
                guild_id INTEGER NOT NULL, role_id INTEGER NOT NULL,
                label TEXT NOT NULL, emoji TEXT NOT NULL DEFAULT '',
                PRIMARY KEY(guild_id,role_id)
            );
            CREATE TABLE IF NOT EXISTS mega_market_listings (
                id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL,
                seller_id INTEGER NOT NULL, item_key TEXT NOT NULL,
                quantity INTEGER NOT NULL, unit_price INTEGER NOT NULL,
                status TEXT NOT NULL DEFAULT 'open', created_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS mega_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL,
                creator_id INTEGER NOT NULL, title TEXT NOT NULL, starts_at REAL NOT NULL,
                description TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'open',
                created_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS mega_event_members (
                event_id INTEGER NOT NULL, user_id INTEGER NOT NULL, joined_at REAL NOT NULL,
                PRIMARY KEY(event_id,user_id)
            );
            CREATE TABLE IF NOT EXISTS mega_voice_sessions (
                guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, joined_at REAL NOT NULL,
                PRIMARY KEY(guild_id,user_id)
            );
            """
        )
        # A process restart invalidates in-memory voice intervals; clear stale sessions.
        self.db.execute("DELETE FROM mega_voice_sessions")
        self.db.commit()

    @staticmethod
    def today() -> str:
        return datetime.now(timezone.utc).date().isoformat()

    @staticmethod
    def yesterday() -> str:
        return (datetime.now(timezone.utc).date() - timedelta(days=1)).isoformat()

    @staticmethod
    def clean_text(text: str, limit: int = 500) -> str:
        text = discord.utils.escape_mentions(str(text))
        text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", text)
        return text.strip()[:limit]

    @staticmethod
    def normalize(text: str) -> str:
        mapping = str.maketrans({
            "İ": "i", "I": "i", "ı": "i",
            "Ş": "s", "ş": "s", "Ğ": "g", "ğ": "g",
            "Ü": "u", "ü": "u", "Ö": "o", "ö": "o",
            "Ç": "c", "ç": "c",
        })
        return str(text).translate(mapping).casefold().strip()

    def ensure_account(self, guild_id: int, user_id: int) -> None:
        self.db.execute(
            "INSERT OR IGNORE INTO economy(guild_id,user_id,balance) VALUES(?,?,1000)",
            (guild_id, user_id),
        )

    def balance(self, guild_id: int, user_id: int) -> int:
        self.ensure_account(guild_id, user_id)
        self.db.commit()
        row = self.db.execute(
            "SELECT balance FROM economy WHERE guild_id=? AND user_id=?",
            (guild_id, user_id),
        ).fetchone()
        return int(row[0]) if row else 0

    def transfer(self, guild_id: int, sender_id: int, receiver_id: int, amount: int) -> bool:
        if amount <= 0 or sender_id == receiver_id:
            return False
        try:
            self.db.execute("BEGIN IMMEDIATE")
            self.ensure_account(guild_id, sender_id)
            self.ensure_account(guild_id, receiver_id)
            row = self.db.execute(
                "SELECT balance FROM economy WHERE guild_id=? AND user_id=?",
                (guild_id, sender_id),
            ).fetchone()
            if not row or int(row[0]) < amount:
                self.db.rollback()
                return False
            self.db.execute(
                "UPDATE economy SET balance=balance-? WHERE guild_id=? AND user_id=?",
                (amount, guild_id, sender_id),
            )
            self.db.execute(
                "UPDATE economy SET balance=balance+? WHERE guild_id=? AND user_id=?",
                (amount, guild_id, receiver_id),
            )
            self.db.commit()
            return True
        except sqlite3.Error:
            self.db.rollback()
            raise

    def add_money(self, guild_id: int, user_id: int, amount: int) -> None:
        if amount <= 0:
            raise ValueError("amount must be positive")
        self.ensure_account(guild_id, user_id)
        self.db.execute(
            "UPDATE economy SET balance=balance+? WHERE guild_id=? AND user_id=?",
            (amount, guild_id, user_id),
        )
        self.db.commit()

    def award_badge(self, guild_id: int, user_id: int, badge_key: str) -> bool:
        self.db.execute(
            "INSERT OR IGNORE INTO mega_badges(guild_id,user_id,badge_key,earned_at) VALUES(?,?,?,?)",
            (guild_id, user_id, badge_key[:60], time.time()),
        )
        earned = self.db.execute("SELECT changes()").fetchone()[0] > 0
        self.db.commit()
        return earned

    def get_config(self, guild_id: int) -> sqlite3.Row:
        row = self.db.execute("SELECT * FROM mega_guild_config WHERE guild_id=?", (guild_id,)).fetchone()
        if row is None:
            self.db.execute("INSERT OR IGNORE INTO mega_guild_config(guild_id) VALUES(?)", (guild_id,))
            self.db.commit()
            row = self.db.execute("SELECT * FROM mega_guild_config WHERE guild_id=?", (guild_id,)).fetchone()
        return row

    async def send_modlog(
        self, guild: discord.Guild, action: str, target_id: Optional[int] = None,
        actor_id: Optional[int] = None, reason: str = "",
    ) -> None:
        if guild is None:
            return
        cfg = self.get_config(guild.id)
        self.db.execute(
            "INSERT INTO mega_modlog(guild_id,actor_id,target_id,action,reason,created_at) VALUES(?,?,?,?,?,?)",
            (guild.id, actor_id, target_id, action[:60], reason[:500], time.time()),
        )
        self.db.commit()
        channel_id = cfg["modlog_channel_id"]
        if not channel_id:
            return
        channel = guild.get_channel(int(channel_id))
        if channel is None:
            return
        embed = discord.Embed(title="Baklava1923 işlem kaydı", color=discord.Color.orange(), timestamp=datetime.now(timezone.utc))
        embed.add_field(name="İşlem", value=action[:100], inline=True)
        embed.add_field(name="Hedef", value=f"`{target_id}`" if target_id else "Belirtilmedi", inline=True)
        embed.add_field(name="Yetkili", value=f"`{actor_id}`" if actor_id else "Sistem", inline=True)
        if reason:
            embed.add_field(name="Açıklama", value=reason[:900], inline=False)
        try:
            await channel.send(embed=embed)
        except discord.HTTPException:
            pass

    async def require_guild(self, ctx: commands.Context) -> bool:
        if ctx.guild is None:
            await ctx.send("Bu komut yalnızca sunucuda kullanılabilir")
            return False
        return True

    @commands.command(name="mega-yardim")
    async def mega_help(self, ctx: commands.Context) -> None:
        pages = []
        sections = [
            ("Ekonomi ve koleksiyon", "`B!günlükbonus` `B!haftalıkbonus` `B!bağış` `B!koleksiyon` `B!koleksiyonal` `B!koleksiyonsat` `B!itibar` `B!itibarver`"),
            ("Kulüpler ve topluluk", "`B!kulüpkur` `B!kulüpler` `B!kulübe-gir` `B!kulüptenayrıl` `B!kulüpbilgi` `B!kulüpkatkı` `B!kulüpliderlik`"),
            ("Profil ve sosyal", "`B!biyografi` `B!benkimim` `B!rozetlerim` `B!avatar` `B!banner` `B!kullanıcıbilgisi`"),
            ("Oyunlar ve zihin", "`B!matematikoyunu` `B!bilgiyarışması` `B!kelimekarıştır` `B!bulmaca` `B!bulmaca-cevap`"),
            ("Sunucu araçları", "`B!hoşgeldinkanal` `B!hoşgeldinkapat` `B!modlogayarla` `B!modgeçmiş` `B!filtrekelimeekle` `B!filtrekelimesil` `B!filtreayar` `B!güvenlikdurumu`"),
            ("Öneri ve rol menüsü", "`B!öneriver` `B!önerionayla` `B!önerireddet` `B!öneriler` `B!rolseçimkur` `B!rolmenüsü` `B!rolseç`"),
            ("Araçlar", "`B!hesapla` `B!tarih` `B!emojiler` `B!sunucukartı` `B!hedefoluştur` `B!hedefim` `B!hedefkatkı`"),
        ]
        for title, body in sections:
            embed = discord.Embed(title=f"Baklava1923 Bot 3.6.2 MEGA · {title}", description=body, color=discord.Color.gold())
            embed.set_footer(text=f"{ctx.author.display_name} için yardım menüsü")
            pages.append(embed)
        view = EmbedPager(pages, ctx.author.id)
        await ctx.send(embed=pages[0], view=view)

    @commands.command(name="mega-komutlar")
    async def mega_command_count(self, ctx: commands.Context) -> None:
        commands_list = sorted({command.qualified_name for command in self.bot.commands})
        embed = discord.Embed(title="Baklava1923 komut dizini", color=discord.Color.gold())
        embed.description = f"Toplam kayıtlı prefix komutu: **{len(commands_list)}**\n\n" + " · ".join(f"`{name}`" for name in commands_list[:80])
        if len(commands_list) > 80:
            embed.set_footer(text=f"İlk 80 komut gösteriliyor · kalan {len(commands_list) - 80} komut mega-yardım menüsünde kategorili")
        await ctx.send(embed=embed)

    @commands.command(name="günlükbonus", aliases=["gunlukbonus", "dailybonus"])
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def daily_bonus(self, ctx: commands.Context) -> None:
        if not await self.require_guild(ctx):
            return
        guild_id, user_id = ctx.guild.id, ctx.author.id
        today, yesterday = self.today(), self.yesterday()
        row = self.db.execute(
            "SELECT last_claim,streak FROM mega_daily WHERE guild_id=? AND user_id=?",
            (guild_id, user_id),
        ).fetchone()
        if row and row["last_claim"] == today:
            await ctx.send("Bugünkü giriş ödülünü zaten aldın yarın yeniden gel")
            return
        old_streak = int(row["streak"]) if row else 0
        streak = old_streak + 1 if row and row["last_claim"] == yesterday else 1
        reward = DAILY_REWARDS[min(streak - 1, len(DAILY_REWARDS) - 1)]
        self.db.execute(
            "INSERT INTO mega_daily(guild_id,user_id,last_claim,streak) VALUES(?,?,?,?) "
            "ON CONFLICT(guild_id,user_id) DO UPDATE SET last_claim=excluded.last_claim,streak=excluded.streak",
            (guild_id, user_id, today, streak),
        )
        self.add_money(guild_id, user_id, reward)
        if streak >= 7:
            self.award_badge(guild_id, user_id, "7 Günlük Seri")
        if streak >= 30:
            self.award_badge(guild_id, user_id, "30 Günlük İstikrar")
        await ctx.send(f"Günlük ödülün **{reward:,}** paklavan ve seri günün **{streak}**")

    @commands.command(name="haftalıkbonus", aliases=["haftalikbonus", "weeklybonus"])
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def weekly_bonus(self, ctx: commands.Context) -> None:
        if not await self.require_guild(ctx):
            return
        now = datetime.now(timezone.utc)
        iso_week = f"{now.isocalendar().year}-W{now.isocalendar().week:02d}"
        row = self.db.execute(
            "SELECT weekly_claim FROM mega_daily WHERE guild_id=? AND user_id=?",
            (ctx.guild.id, ctx.author.id),
        ).fetchone()
        if row and row["weekly_claim"] == iso_week:
            await ctx.send("Bu haftanın ödülünü zaten aldın")
            return
        self.db.execute(
            "INSERT INTO mega_daily(guild_id,user_id,weekly_claim) VALUES(?,?,?) "
            "ON CONFLICT(guild_id,user_id) DO UPDATE SET weekly_claim=excluded.weekly_claim",
            (ctx.guild.id, ctx.author.id, iso_week),
        )
        self.add_money(ctx.guild.id, ctx.author.id, WEEKLY_REWARD)
        await ctx.send(f"Haftalık ödülün **{WEEKLY_REWARD:,}** paklava hesabına eklendi")

    @commands.command(name="bağış", aliases=["bagis", "bahşiş", "bahsis"])
    @commands.guild_only()
    @commands.cooldown(1, 4, commands.BucketType.user)
    async def give_money(self, ctx: commands.Context, member: discord.Member, amount: int) -> None:
        if member.bot or member.id == ctx.author.id:
            await ctx.send("Kendine veya bot hesabına para gönderemezsin")
            return
        if amount < 1 or amount > 1_000_000:
            await ctx.send("Miktar 1 ile 1000000 arasında olmalı")
            return
        if not self.transfer(ctx.guild.id, ctx.author.id, member.id, amount):
            await ctx.send("Yeterli bakiyen yok veya işlem geçersiz")
            return
        await ctx.send(f"{ctx.author.mention} → {member.mention} **{amount:,}** paklava gönderdi")

    @commands.command(name="itibar")
    async def reputation(self, ctx: commands.Context, member: Optional[discord.Member] = None) -> None:
        if not await self.require_guild(ctx):
            return
        member = member or ctx.author
        row = self.db.execute(
            "SELECT points FROM mega_reputation WHERE guild_id=? AND user_id=?",
            (ctx.guild.id, member.id),
        ).fetchone()
        points = int(row[0]) if row else 0
        await ctx.send(f"{member.mention} kullanıcısının topluluk itibarı **{points}** puan")

    @commands.command(name="itibarver", aliases=["itibarverme"])
    @commands.guild_only()
    @commands.cooldown(1, 30, commands.BucketType.user)
    async def give_reputation(self, ctx: commands.Context, member: discord.Member) -> None:
        if member.bot or member.id == ctx.author.id:
            await ctx.send("İtibarını kendine veya botlara veremezsin")
            return
        row = self.db.execute(
            "SELECT last_given FROM mega_reputation WHERE guild_id=? AND user_id=?",
            (ctx.guild.id, ctx.author.id),
        ).fetchone()
        if row and time.time() - float(row[0]) < 86400:
            remaining = int(86400 - (time.time() - float(row[0])))
            await ctx.send(f"Yeniden itibar vermek için {remaining // 3600} saat beklemelisin")
            return
        self.db.execute(
            "INSERT INTO mega_reputation(guild_id,user_id,points,last_given) VALUES(?,?,0,?) "
            "ON CONFLICT(guild_id,user_id) DO UPDATE SET last_given=excluded.last_given",
            (ctx.guild.id, ctx.author.id, time.time()),
        )
        self.db.execute(
            "INSERT INTO mega_reputation(guild_id,user_id,points,last_given) VALUES(?,?,1,0) "
            "ON CONFLICT(guild_id,user_id) DO UPDATE SET points=points+1",
            (ctx.guild.id, member.id),
        )
        self.db.execute(
            "INSERT INTO mega_rep_history(guild_id,giver_id,receiver_id,created_at) VALUES(?,?,?,?)",
            (ctx.guild.id, ctx.author.id, member.id, time.time()),
        )
        self.db.commit()
        await ctx.send(f"{member.mention} bir itibar puanı kazandı")

    @commands.command(name="biyografi", aliases=["bioayarla", "biyografim"])
    @commands.guild_only()
    async def set_bio(self, ctx: commands.Context, *, text: str) -> None:
        clean = self.clean_text(text, MAX_BIO_LENGTH)
        self.db.execute(
            "INSERT INTO mega_profiles(guild_id,user_id,bio,updated_at) VALUES(?,?,?,?) "
            "ON CONFLICT(guild_id,user_id) DO UPDATE SET bio=excluded.bio,updated_at=excluded.updated_at",
            (ctx.guild.id, ctx.author.id, clean, time.time()),
        )
        self.db.commit()
        await ctx.send(f"Biyografin güncellendi\n`{clean}`")

    @commands.command(name="benkimim", aliases=["profilim2", "kartım"])
    @commands.guild_only()
    async def profile_card(self, ctx: commands.Context, member: Optional[discord.Member] = None) -> None:
        member = member or ctx.author
        row = self.db.execute(
            "SELECT bio,profile_title FROM mega_profiles WHERE guild_id=? AND user_id=?",
            (ctx.guild.id, member.id),
        ).fetchone()
        bio = row["bio"] if row else "Henüz biyografi eklenmemiş"
        title = row["profile_title"] if row else "Topluluk üyesi"
        rep_row = self.db.execute(
            "SELECT points FROM mega_reputation WHERE guild_id=? AND user_id=?",
            (ctx.guild.id, member.id),
        ).fetchone()
        rep = int(rep_row[0]) if rep_row else 0
        balance = self.balance(ctx.guild.id, member.id)
        streak_row = self.db.execute(
            "SELECT streak FROM mega_daily WHERE guild_id=? AND user_id=?",
            (ctx.guild.id, member.id),
        ).fetchone()
        streak = int(streak_row[0]) if streak_row else 0
        embed = discord.Embed(title=f"{member.display_name} · Profil Kartı", description=bio, color=member.color if member.color.value else discord.Color.gold())
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="Unvan", value=title or "Topluluk üyesi", inline=True)
        embed.add_field(name="Cüzdan", value=f"{balance:,}", inline=True)
        embed.add_field(name="İtibar", value=str(rep), inline=True)
        embed.add_field(name="Günlük seri", value=f"{streak} gün", inline=True)
        embed.add_field(name="Sunucudaki katılım", value=member.joined_at.strftime("%d.%m.%Y") if member.joined_at else "Bilinmiyor", inline=True)
        await ctx.send(embed=embed)

    @commands.command(name="rozetlerim", aliases=["rozetler", "rozetkoleksiyonum"])
    @commands.guild_only()
    async def my_badges(self, ctx: commands.Context, member: Optional[discord.Member] = None) -> None:
        member = member or ctx.author
        rows = self.db.execute(
            "SELECT badge_key,earned_at FROM mega_badges WHERE guild_id=? AND user_id=? ORDER BY earned_at DESC",
            (ctx.guild.id, member.id),
        ).fetchall()
        if not rows:
            await ctx.send(f"{member.mention} henüz mega rozeti kazanmamış")
            return
        lines = [f"• **{discord.utils.escape_markdown(row['badge_key'])}** · <t:{int(row['earned_at'])}:d>" for row in rows[:25]]
        await ctx.send(embed=discord.Embed(title=f"{member.display_name} rozetleri", description="\n".join(lines), color=discord.Color.gold()))

    @commands.command(name="koleksiyon")
    @commands.guild_only()
    async def collection(self, ctx: commands.Context, member: Optional[discord.Member] = None) -> None:
        member = member or ctx.author
        rows = self.db.execute(
            "SELECT item_key,quantity FROM mega_inventory WHERE guild_id=? AND user_id=? AND quantity>0 ORDER BY item_key",
            (ctx.guild.id, member.id),
        ).fetchall()
        if not rows:
            await ctx.send("Koleksiyonun henüz boş `B!koleksiyonmağazası` komutuna bak")
            return
        lines = []
        for row in rows[:30]:
            item = SHOP_CATALOG.get(row["item_key"], {"name": row["item_key"]})
            lines.append(f"**{item['name']}** × {row['quantity']}")
        await ctx.send(embed=discord.Embed(title=f"{member.display_name} koleksiyonu", description="\n".join(lines), color=discord.Color.gold()))

    @commands.command(name="koleksiyonmağazası", aliases=["koleksiyonmagazasi", "megashop"])
    async def collection_shop(self, ctx: commands.Context) -> None:
        pages = []
        entries = list(SHOP_CATALOG.items())
        for start in range(0, len(entries), 5):
            embed = discord.Embed(title="Baklava koleksiyon mağazası", color=discord.Color.gold())
            for key, item in entries[start:start + 5]:
                embed.add_field(name=f"{item['name']} · {item['price']:,}", value=f"`{key}`\n{item['description']}", inline=False)
            embed.set_footer(text="Satın almak için B!koleksiyonal eşya_kodu")
            pages.append(embed)
        pager = EmbedPager(pages, ctx.author.id)
        await ctx.send(embed=pages[0], view=pager)

    @commands.command(name="koleksiyonal")
    @commands.guild_only()
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def collection_buy(self, ctx: commands.Context, item_key: str, amount: int = 1) -> None:
        item_key = self.normalize(item_key).replace(" ", "_")
        item = SHOP_CATALOG.get(item_key)
        if not item:
            await ctx.send("Böyle bir eşya yok mağazayı `B!koleksiyonmağazası` ile aç")
            return
        if amount < 1 or amount > 25:
            await ctx.send("Bir seferde 1 ile 25 adet arasında alabilirsin")
            return
        total = item["price"] * amount
        try:
            self.db.execute("BEGIN IMMEDIATE")
            self.ensure_account(ctx.guild.id, ctx.author.id)
            row = self.db.execute("SELECT balance FROM economy WHERE guild_id=? AND user_id=?", (ctx.guild.id, ctx.author.id)).fetchone()
            if not row or int(row[0]) < total:
                self.db.rollback()
                await ctx.send(f"Bu alışveriş için **{total:,}** paklava gerekiyor")
                return
            self.db.execute("UPDATE economy SET balance=balance-? WHERE guild_id=? AND user_id=?", (total, ctx.guild.id, ctx.author.id))
            self.db.execute(
                "INSERT INTO mega_inventory(guild_id,user_id,item_key,quantity) VALUES(?,?,?,?) "
                "ON CONFLICT(guild_id,user_id,item_key) DO UPDATE SET quantity=quantity+excluded.quantity",
                (ctx.guild.id, ctx.author.id, item_key, amount),
            )
            self.db.commit()
        except sqlite3.Error:
            self.db.rollback()
            await ctx.send("Alışveriş kaydedilemedi tekrar dene")
            return
        await ctx.send(f"{amount} adet **{item['name']}** aldın toplam **{total:,}** paklava harcadın")

    @commands.command(name="koleksiyonsat")
    @commands.guild_only()
    async def collection_sell(self, ctx: commands.Context, item_key: str, amount: int = 1) -> None:
        item_key = self.normalize(item_key).replace(" ", "_")
        item = SHOP_CATALOG.get(item_key)
        if not item or amount < 1 or amount > 25:
            await ctx.send("Eşya kodunu veya miktarı kontrol et")
            return
        row = self.db.execute(
            "SELECT quantity FROM mega_inventory WHERE guild_id=? AND user_id=? AND item_key=?",
            (ctx.guild.id, ctx.author.id, item_key),
        ).fetchone()
        if not row or int(row[0]) < amount:
            await ctx.send("Bu kadar eşyan bulunmuyor")
            return
        refund = max(1, int(item["price"] * 0.55)) * amount
        self.db.execute(
            "UPDATE mega_inventory SET quantity=quantity-? WHERE guild_id=? AND user_id=? AND item_key=?",
            (amount, ctx.guild.id, ctx.author.id, item_key),
        )
        self.add_money(ctx.guild.id, ctx.author.id, refund)
        await ctx.send(f"{amount} adet {item['name']} sattın ve **{refund:,}** paklava aldın")

    @commands.command(name="kulüpkur", aliases=["kulupkur"])
    @commands.guild_only()
    @commands.cooldown(1, 300, commands.BucketType.user)
    async def create_club(self, ctx: commands.Context, name: str, *, description: str = "Yeni bir topluluk kulübü") -> None:
        name = self.clean_text(name, MAX_CLUB_NAME)
        description = self.clean_text(description, MAX_CLUB_DESCRIPTION)
        if len(name) < 3:
            await ctx.send("Kulüp adı en az 3 karakter olmalı")
            return
        existing = self.db.execute(
            "SELECT club_id FROM mega_club_members WHERE guild_id=? AND user_id=?",
            (ctx.guild.id, ctx.author.id),
        ).fetchone()
        if existing:
            await ctx.send("Zaten bir kulüptesin önce mevcut kulüpten ayrıl")
            return
        slug = re.sub(r"[^a-z0-9ğüşöçı]+", "-", self.normalize(name)).strip("-")[:32]
        try:
            self.db.execute(
                "INSERT INTO mega_clubs(guild_id,name,slug,description,owner_id,created_at) VALUES(?,?,?,?,?,?)",
                (ctx.guild.id, name, slug, description, ctx.author.id, time.time()),
            )
            club_id = self.db.execute("SELECT last_insert_rowid()").fetchone()[0]
            self.db.execute(
                "INSERT INTO mega_club_members(guild_id,club_id,user_id,joined_at,role) VALUES(?,?,?,?, 'leader')",
                (ctx.guild.id, club_id, ctx.author.id, time.time()),
            )
            self.db.commit()
        except sqlite3.IntegrityError:
            self.db.rollback()
            await ctx.send("Bu isimle bir kulüp zaten var")
            return
        self.award_badge(ctx.guild.id, ctx.author.id, "Kulüp Kurucusu")
        await ctx.send(f"**{name}** kulübünü kurdun kulüp kodu `{club_id}`")

    @commands.command(name="kulüpler", aliases=["kulupler"])
    @commands.guild_only()
    async def list_clubs(self, ctx: commands.Context) -> None:
        rows = self.db.execute(
            "SELECT c.id,c.name,c.description,c.bank,COUNT(m.user_id) AS members "
            "FROM mega_clubs c LEFT JOIN mega_club_members m ON m.club_id=c.id AND m.guild_id=c.guild_id "
            "WHERE c.guild_id=? GROUP BY c.id ORDER BY members DESC,c.name LIMIT 20",
            (ctx.guild.id,),
        ).fetchall()
        if not rows:
            await ctx.send("Henüz kulüp yok `B!kulüpkur isim açıklama` ile ilkini sen oluştur")
            return
        lines = [f"**#{row['id']} {discord.utils.escape_markdown(row['name'])}** · {row['members']} üye · banka {row['bank']:,}\n{row['description']}" for row in rows]
        await ctx.send(embed=discord.Embed(title="Sunucu kulüpleri", description="\n\n".join(lines), color=discord.Color.gold()))

    @commands.command(name="kulübe-gir", aliases=["kulupegir"])
    @commands.guild_only()
    async def join_club(self, ctx: commands.Context, club_id: int) -> None:
        if club_id < 1:
            await ctx.send("Geçerli bir kulüp kodu yaz")
            return
        current = self.db.execute("SELECT club_id FROM mega_club_members WHERE guild_id=? AND user_id=?", (ctx.guild.id, ctx.author.id)).fetchone()
        if current:
            await ctx.send("Zaten bir kulüptesin önce ayrılmalısın")
            return
        club = self.db.execute("SELECT name FROM mega_clubs WHERE guild_id=? AND id=?", (ctx.guild.id, club_id)).fetchone()
        if not club:
            await ctx.send("Bu kulüp bulunamadı")
            return
        try:
            self.db.execute(
                "INSERT INTO mega_club_members(guild_id,club_id,user_id,joined_at) VALUES(?,?,?,?)",
                (ctx.guild.id, club_id, ctx.author.id, time.time()),
            )
            self.db.commit()
        except sqlite3.IntegrityError:
            await ctx.send("Zaten bu kulübe kayıtlısın")
            return
        await ctx.send(f"**{club['name']}** kulübüne katıldın")

    @commands.command(name="kulüptenayrıl", aliases=["kuluptenayril"])
    @commands.guild_only()
    async def leave_club(self, ctx: commands.Context) -> None:
        row = self.db.execute("SELECT club_id,role FROM mega_club_members WHERE guild_id=? AND user_id=?", (ctx.guild.id, ctx.author.id)).fetchone()
        if not row:
            await ctx.send("Bir kulüpte değilsin")
            return
        count = self.db.execute("SELECT COUNT(*) FROM mega_club_members WHERE guild_id=? AND club_id=?", (ctx.guild.id, row["club_id"])).fetchone()[0]
        if row["role"] == "leader" and count > 1:
            await ctx.send("Kulüp lideri ayrılmadan önce liderliği devretmeli")
            return
        if row["role"] == "leader":
            self.db.execute("DELETE FROM mega_clubs WHERE guild_id=? AND id=?", (ctx.guild.id, row["club_id"]))
        else:
            self.db.execute("DELETE FROM mega_club_members WHERE guild_id=? AND user_id=?", (ctx.guild.id, ctx.author.id))
        self.db.commit()
        await ctx.send("Kulüpten ayrıldın")

    @commands.command(name="kulüpbilgi", aliases=["kulupbilgi"])
    @commands.guild_only()
    async def club_info(self, ctx: commands.Context, club_id: Optional[int] = None) -> None:
        if club_id is None:
            own = self.db.execute("SELECT club_id FROM mega_club_members WHERE guild_id=? AND user_id=?", (ctx.guild.id, ctx.author.id)).fetchone()
            if not own:
                await ctx.send("Bir kulüp kodu yaz veya önce bir kulübe katıl")
                return
            club_id = int(own[0])
        row = self.db.execute(
            "SELECT c.*,COUNT(m.user_id) AS members FROM mega_clubs c "
            "LEFT JOIN mega_club_members m ON m.club_id=c.id AND m.guild_id=c.guild_id "
            "WHERE c.guild_id=? AND c.id=? GROUP BY c.id",
            (ctx.guild.id, club_id),
        ).fetchone()
        if not row:
            await ctx.send("Kulüp bulunamadı")
            return
        embed = discord.Embed(title=f"{row['name']} · Kulüp kartı", description=row["description"], color=discord.Color.gold())
        embed.add_field(name="Kod", value=str(row["id"]), inline=True)
        embed.add_field(name="Üye", value=str(row["members"]), inline=True)
        embed.add_field(name="Kulüp bankası", value=f"{row['bank']:,}", inline=True)
        embed.add_field(name="Kurucu", value=f"<@{row['owner_id']}>", inline=True)
        await ctx.send(embed=embed)

    @commands.command(name="kulüpkatkı", aliases=["kulupkatki"])
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def club_contribute(self, ctx: commands.Context, amount: int) -> None:
        if amount < 1 or amount > 100_000:
            await ctx.send("Katkı miktarı 1 ile 100000 arasında olmalı")
            return
        member_row = self.db.execute("SELECT club_id FROM mega_club_members WHERE guild_id=? AND user_id=?", (ctx.guild.id, ctx.author.id)).fetchone()
        if not member_row:
            await ctx.send("Önce bir kulübe katılmalısın")
            return
        try:
            self.db.execute("BEGIN IMMEDIATE")
            self.ensure_account(ctx.guild.id, ctx.author.id)
            balance = self.db.execute("SELECT balance FROM economy WHERE guild_id=? AND user_id=?", (ctx.guild.id, ctx.author.id)).fetchone()[0]
            if balance < amount:
                self.db.rollback()
                await ctx.send("Bu katkı için yeterli bakiyen yok")
                return
            club_id = int(member_row[0])
            self.db.execute("UPDATE economy SET balance=balance-? WHERE guild_id=? AND user_id=?", (amount, ctx.guild.id, ctx.author.id))
            self.db.execute("UPDATE mega_clubs SET bank=bank+? WHERE guild_id=? AND id=?", (amount, ctx.guild.id, club_id))
            self.db.execute("UPDATE mega_club_members SET contribution=contribution+? WHERE guild_id=? AND club_id=? AND user_id=?", (amount, ctx.guild.id, club_id, ctx.author.id))
            self.db.commit()
        except sqlite3.Error:
            self.db.rollback()
            await ctx.send("Katkı kaydedilemedi")
            return
        await ctx.send(f"Kulübüne **{amount:,}** paklava katkıda bulundun")

    @commands.command(name="kulüpliderlik", aliases=["kulupliderlik"])
    @commands.guild_only()
    async def club_leaderboard(self, ctx: commands.Context) -> None:
        rows = self.db.execute(
            "SELECT name,bank FROM mega_clubs WHERE guild_id=? ORDER BY bank DESC LIMIT 10",
            (ctx.guild.id,),
        ).fetchall()
        if not rows:
            await ctx.send("Henüz sıralanacak kulüp yok")
            return
        lines = [f"**{index}. {row['name']}** — {row['bank']:,} paklava" for index, row in enumerate(rows, 1)]
        await ctx.send(embed=discord.Embed(title="Kulüp bankası sıralaması", description="\n".join(lines), color=discord.Color.gold()))

    @commands.command(name="hedefoluştur", aliases=["hedefkur"])
    @commands.guild_only()
    @commands.has_guild_permissions(manage_guild=True)
    async def create_goal(self, ctx: commands.Context, target: int, reward: int, *, title: str) -> None:
        title = self.clean_text(title, 80)
        if target < 1 or target > 1_000_000 or reward < 0 or reward > 100_000:
            await ctx.send("Hedef 1-1000000, ödül 0-100000 arasında olmalı")
            return
        self.db.execute(
            "INSERT INTO mega_goals(guild_id,owner_id,title,target,reward,created_at) VALUES(?,?,?,?,?,?)",
            (ctx.guild.id, ctx.author.id, title, target, reward, time.time()),
        )
        goal_id = self.db.execute("SELECT last_insert_rowid()").fetchone()[0]
        self.db.commit()
        await ctx.send(f"Sunucu hedefi oluşturuldu `{goal_id}` · **{title}** · hedef **{target}** · ödül **{reward}**")

    @commands.command(name="hedefim", aliases=["hedefler"])
    @commands.guild_only()
    async def goal_list(self, ctx: commands.Context) -> None:
        rows = self.db.execute(
            "SELECT id,title,target,current,reward,status FROM mega_goals WHERE guild_id=? AND status='open' ORDER BY id DESC LIMIT 10",
            (ctx.guild.id,),
        ).fetchall()
        if not rows:
            await ctx.send("Açık sunucu hedefi yok")
            return
        lines = []
        for row in rows:
            percent = min(100, int(row["current"] * 100 / max(1, row["target"])))
            bars = "█" * (percent // 10) + "░" * (10 - percent // 10)
            lines.append(f"`#{row['id']}` **{row['title']}**\n{bars} {row['current']}/{row['target']} · {percent}% · ödül {row['reward']}")
        await ctx.send(embed=discord.Embed(title="Sunucu hedefleri", description="\n\n".join(lines), color=discord.Color.gold()))

    @commands.command(name="hedefkatkı", aliases=["hedefkatki"])
    @commands.guild_only()
    async def goal_contribute(self, ctx: commands.Context, goal_id: int, amount: int = 1) -> None:
        if amount < 1 or amount > 1000:
            await ctx.send("Katkı 1 ile 1000 arasında olmalı")
            return
        self.db.execute("BEGIN IMMEDIATE")
        row = self.db.execute("SELECT target,current,status,reward FROM mega_goals WHERE guild_id=? AND id=?", (ctx.guild.id, goal_id)).fetchone()
        if not row or row["status"] != "open":
            self.db.rollback()
            await ctx.send("Açık hedef bulunamadı")
            return
        remaining = int(row["target"]) - int(row["current"])
        actual = min(amount, remaining)
        if actual <= 0:
            self.db.rollback()
            await ctx.send("Bu hedef zaten tamamlanmış")
            return
        self.db.execute("UPDATE mega_goals SET current=current+? WHERE guild_id=? AND id=?", (actual, ctx.guild.id, goal_id))
        self.db.execute(
            "INSERT INTO mega_goal_members(goal_id,user_id,contribution) VALUES(?,?,?) "
            "ON CONFLICT(goal_id,user_id) DO UPDATE SET contribution=contribution+excluded.contribution",
            (goal_id, ctx.author.id, actual),
        )
        updated = int(row["current"]) + actual
        payout_lines = []
        if updated >= int(row["target"]):
            self.db.execute("UPDATE mega_goals SET status='completed' WHERE guild_id=? AND id=?", (ctx.guild.id, goal_id))
            contributors = self.db.execute("SELECT user_id,contribution FROM mega_goal_members WHERE goal_id=?", (goal_id,)).fetchall()
            total_contribution = sum(int(item["contribution"]) for item in contributors)
            reward_pool = int(row["reward"])
            for contributor in contributors:
                share = (reward_pool * int(contributor["contribution"])) // max(1, total_contribution)
                if share > 0:
                    self.ensure_account(ctx.guild.id, int(contributor["user_id"]))
                    self.db.execute("UPDATE economy SET balance=balance+? WHERE guild_id=? AND user_id=?", (share, ctx.guild.id, int(contributor["user_id"])))
                    payout_lines.append(f"<@{contributor['user_id']}> +{share:,}")
        self.db.commit()
        if updated >= int(row["target"]):
            payout = "\n".join(payout_lines[:10]) if payout_lines else "Ödül havuzu 0"
            await ctx.send(f"Hedef tamamlandı sunucu hedefe ulaştı\nÖdül dağıtımı\n{payout}")
        else:
            await ctx.send(f"Hedefe **{actual}** katkı yaptın · ilerleme **{updated}/{row['target']}**")

    @commands.command(name="rolseçimkur", aliases=["rolsecimkur"])
    @commands.guild_only()
    @commands.has_guild_permissions(manage_roles=True)
    async def self_role_add(self, ctx: commands.Context, role: discord.Role, *, label: Optional[str] = None) -> None:
        if role.is_default() or role.managed or role >= ctx.guild.me.top_role:
            await ctx.send("Bu rol güvenli öz rol listesine eklenemez botun rolünden yukarıda veya yönetilen bir rol")
            return
        if role.permissions.administrator or role.permissions.manage_guild or role.permissions.manage_roles or role.permissions.ban_members:
            await ctx.send("Yönetici veya moderasyon yetkisi taşıyan roller öz rol listesine eklenemez")
            return
        count = self.db.execute("SELECT COUNT(*) FROM mega_self_roles WHERE guild_id=?", (ctx.guild.id,)).fetchone()[0]
        if count >= MAX_SELF_ROLES:
            await ctx.send(f"Bir sunucuda en fazla {MAX_SELF_ROLES} öz rol seçeneği olabilir")
            return
        self.db.execute(
            "INSERT OR REPLACE INTO mega_self_roles(guild_id,role_id,added_by,created_at) VALUES(?,?,?,?)",
            (ctx.guild.id, role.id, ctx.author.id, time.time()),
        )
        clean_label = self.clean_text(label or role.name, 60)
        self.db.execute(
            "INSERT OR REPLACE INTO mega_role_panels(guild_id,role_id,label,emoji) VALUES(?,?,?,'')",
            (ctx.guild.id, role.id, clean_label),
        )
        self.db.commit()
        await ctx.send(f"{role.mention} öz rol menüsüne eklendi")

    @commands.command(name="rolmenüsü", aliases=["rolmenusu"])
    @commands.guild_only()
    async def self_role_menu(self, ctx: commands.Context) -> None:
        rows = self.db.execute(
            "SELECT p.role_id,p.label FROM mega_role_panels p WHERE p.guild_id=? ORDER BY p.label",
            (ctx.guild.id,),
        ).fetchall()
        valid = []
        for row in rows:
            role = ctx.guild.get_role(int(row["role_id"]))
            if role is not None:
                valid.append((role, row["label"]))
        if not valid:
            await ctx.send("Henüz seçilebilir rol eklenmemiş yöneticiler `B!rolseçimkur @rol` kullanabilir")
            return
        lines = [f"`{index}` {role.mention} — {label}" for index, (role, label) in enumerate(valid, 1)]
        await ctx.send(embed=discord.Embed(title="Kendin seç rol menüsü", description="\n".join(lines) + "\n\nRol almak için `B!rolseç numara` yaz", color=discord.Color.gold()))

    @commands.command(name="rolseç", aliases=["rolsec"])
    @commands.guild_only()
    async def self_role_choose(self, ctx: commands.Context, number: int) -> None:
        rows = self.db.execute("SELECT role_id,label FROM mega_role_panels WHERE guild_id=? ORDER BY label", (ctx.guild.id,)).fetchall()
        valid = [(ctx.guild.get_role(int(row["role_id"])), row["label"]) for row in rows]
        valid = [(role, label) for role, label in valid if role is not None]
        if number < 1 or number > len(valid):
            await ctx.send("Geçerli rol numarasını `B!rolmenüsü` ile görebilirsin")
            return
        role, label = valid[number - 1]
        if role in ctx.author.roles:
            await ctx.author.remove_roles(role, reason="Kullanıcı öz rol menüsünden kaldırdı")
            await ctx.send(f"{role.name} rolü kaldırıldı")
        else:
            await ctx.author.add_roles(role, reason="Kullanıcı öz rol menüsünden seçti")
            await ctx.send(f"{role.name} rolü verildi")

    @commands.command(name="hoşgeldinkanal", aliases=["hosgeldinkanal"])
    @commands.guild_only()
    @commands.has_guild_permissions(manage_guild=True)
    async def set_welcome_channel(self, ctx: commands.Context, channel: discord.TextChannel) -> None:
        self.db.execute("INSERT OR IGNORE INTO mega_guild_config(guild_id) VALUES(?)", (ctx.guild.id,))
        self.db.execute("UPDATE mega_guild_config SET welcome_channel_id=? WHERE guild_id=?", (channel.id, ctx.guild.id))
        self.db.commit()
        await ctx.send(f"Karşılama mesajları {channel.mention} kanalına gönderilecek")

    @commands.command(name="hoşgeldinkapat", aliases=["hosgeldinkapat"])
    @commands.guild_only()
    @commands.has_guild_permissions(manage_guild=True)
    async def disable_welcome(self, ctx: commands.Context) -> None:
        self.db.execute("UPDATE mega_guild_config SET welcome_channel_id=NULL WHERE guild_id=?", (ctx.guild.id,))
        self.db.commit()
        await ctx.send("Karşılama mesajları kapatıldı")

    @commands.command(name="modlogayarla", aliases=["modlogkanal"])
    @commands.guild_only()
    @commands.has_guild_permissions(manage_guild=True)
    async def set_modlog_channel(self, ctx: commands.Context, channel: discord.TextChannel) -> None:
        self.db.execute("INSERT OR IGNORE INTO mega_guild_config(guild_id) VALUES(?)", (ctx.guild.id,))
        self.db.execute("UPDATE mega_guild_config SET modlog_channel_id=? WHERE guild_id=?", (channel.id, ctx.guild.id))
        self.db.commit()
        await ctx.send(f"İşlem kayıtları {channel.mention} kanalına gönderilecek")

    @commands.command(name="modgeçmiş", aliases=["modgecmis", "modlog"])
    @commands.guild_only()
    @commands.has_guild_permissions(view_audit_log=True)
    async def mod_history(self, ctx: commands.Context, limit: int = 10) -> None:
        limit = max(1, min(limit, 25))
        rows = self.db.execute(
            "SELECT actor_id,target_id,action,reason,created_at FROM mega_modlog WHERE guild_id=? ORDER BY id DESC LIMIT ?",
            (ctx.guild.id, limit),
        ).fetchall()
        if not rows:
            await ctx.send("Henüz mega işlem kaydı yok")
            return
        lines = []
        for row in rows:
            stamp = f"<t:{int(row['created_at'])}:R>"
            lines.append(f"{stamp} · **{row['action']}** · yetkili `{row['actor_id'] or 'sistem'}` · hedef `{row['target_id'] or '-'}`\n{row['reason'][:120]}")
        await ctx.send(embed=discord.Embed(title="Mega moderasyon geçmişi", description="\n\n".join(lines), color=discord.Color.orange()))

    @commands.command(name="filtrekelimeekle", aliases=["mega-filtre-ekle"])
    @commands.guild_only()
    @commands.has_guild_permissions(manage_guild=True)
    async def add_filter_word(self, ctx: commands.Context, *, word: str) -> None:
        word = self.normalize(self.clean_text(word, MAX_FILTER_WORD_LENGTH))
        if len(word) < 2:
            await ctx.send("Filtre kelimesi en az 2 karakter olmalı")
            return
        self.db.execute("INSERT OR IGNORE INTO mega_guild_config(guild_id) VALUES(?)", (ctx.guild.id,))
        self.db.execute(
            "INSERT OR IGNORE INTO mega_filter_words(guild_id,word,added_by,created_at) VALUES(?,?,?,?)",
            (ctx.guild.id, word, ctx.author.id, time.time()),
        )
        inserted = self.db.execute("SELECT changes()").fetchone()[0]
        self.db.execute("UPDATE mega_guild_config SET word_filter=1 WHERE guild_id=?", (ctx.guild.id,))
        self.db.commit()
        await ctx.send("Kelime filtresi listesine eklendi" if inserted else "Bu kelime zaten listede")

    @commands.command(name="filtrekelimesil", aliases=["mega-filtre-sil"])
    @commands.guild_only()
    @commands.has_guild_permissions(manage_guild=True)
    async def remove_filter_word(self, ctx: commands.Context, *, word: str) -> None:
        word = self.normalize(self.clean_text(word, MAX_FILTER_WORD_LENGTH))
        self.db.execute("DELETE FROM mega_filter_words WHERE guild_id=? AND word=?", (ctx.guild.id, word))
        removed = self.db.execute("SELECT changes()").fetchone()[0]
        self.db.commit()
        await ctx.send("Kelime filtreden kaldırıldı" if removed else "Bu kelime listede yok")

    @commands.command(name="filtrelistem", aliases=["megafiltrelistesi"])
    @commands.guild_only()
    @commands.has_guild_permissions(manage_guild=True)
    async def list_filter_words(self, ctx: commands.Context) -> None:
        rows = self.db.execute("SELECT word FROM mega_filter_words WHERE guild_id=? ORDER BY word LIMIT 50", (ctx.guild.id,)).fetchall()
        words = [f"`{discord.utils.escape_markdown(row['word'])}`" for row in rows]
        await ctx.send("**Mega filtre listesi**\n" + (" · ".join(words) if words else "Liste boş"))

    @commands.command(name="filtreayar", aliases=["filtreayari"])
    @commands.guild_only()
    @commands.has_guild_permissions(manage_guild=True)
    async def toggle_word_filter(self, ctx: commands.Context, state: str) -> None:
        state = self.normalize(state)
        if state not in ("aç", "ac", "kapat"):
            await ctx.send("Kullanım `B!filtreayar aç` veya `B!filtreayar kapat`")
            return
        enabled = int(state in ("aç", "ac"))
        self.db.execute("INSERT OR IGNORE INTO mega_guild_config(guild_id) VALUES(?)", (ctx.guild.id,))
        self.db.execute("UPDATE mega_guild_config SET word_filter=? WHERE guild_id=?", (enabled, ctx.guild.id))
        self.db.commit()
        await ctx.send("Kelime filtresi açıldı" if enabled else "Kelime filtresi kapatıldı")

    @commands.command(name="davetfiltresi")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_guild=True)
    async def toggle_invite_filter(self, ctx: commands.Context, state: str) -> None:
        state = self.normalize(state)
        if state not in ("aç", "ac", "kapat"):
            await ctx.send("Kullanım `B!davetfiltresi aç` veya `B!davetfiltresi kapat`")
            return
        enabled = int(state in ("aç", "ac"))
        self.db.execute("INSERT OR IGNORE INTO mega_guild_config(guild_id) VALUES(?)", (ctx.guild.id,))
        self.db.execute("UPDATE mega_guild_config SET invite_filter=? WHERE guild_id=?", (enabled, ctx.guild.id))
        self.db.commit()
        await ctx.send("Davet bağlantısı filtresi açıldı" if enabled else "Davet bağlantısı filtresi kapatıldı")

    @commands.command(name="antispamayar", aliases=["antispam"])
    @commands.guild_only()
    @commands.has_guild_permissions(manage_guild=True)
    async def set_spam_filter(self, ctx: commands.Context, state: str, limit: int = 6, seconds: int = 8) -> None:
        state = self.normalize(state)
        if state not in ("aç", "ac", "kapat"):
            await ctx.send("Kullanım `B!antispamayar aç 6 8` veya `B!antispamayar kapat`")
            return
        if not 3 <= limit <= 15 or not 3 <= seconds <= 30:
            await ctx.send("Mesaj sınırı 3-15, zaman aralığı 3-30 saniye olmalı")
            return
        enabled = int(state in ("aç", "ac"))
        self.db.execute("INSERT OR IGNORE INTO mega_guild_config(guild_id) VALUES(?)", (ctx.guild.id,))
        self.db.execute(
            "UPDATE mega_guild_config SET spam_filter=?,spam_limit=?,spam_window=? WHERE guild_id=?",
            (enabled, limit, seconds, ctx.guild.id),
        )
        self.db.commit()
        await ctx.send(f"Spam filtresi {'açıldı' if enabled else 'kapatıldı'} · sınır {limit} mesaj / {seconds} saniye")

    @commands.command(name="güvenlikdurumu", aliases=["guvenlikdurumu"])
    @commands.guild_only()
    @commands.has_guild_permissions(manage_guild=True)
    async def security_status(self, ctx: commands.Context) -> None:
        cfg = self.get_config(ctx.guild.id)
        def state(value: int) -> str:
            return "Açık" if int(value) else "Kapalı"
        embed = discord.Embed(title="Baklava mega güvenlik durumu", color=discord.Color.green())
        embed.add_field(name="Kelime filtresi", value=state(cfg["word_filter"]), inline=True)
        embed.add_field(name="Davet filtresi", value=state(cfg["invite_filter"]), inline=True)
        embed.add_field(name="Spam filtresi", value=state(cfg["spam_filter"]), inline=True)
        embed.add_field(name="Spam sınırı", value=f"{cfg['spam_limit']} mesaj / {cfg['spam_window']} saniye", inline=True)
        embed.add_field(name="Modlog", value=f"<#{cfg['modlog_channel_id']}>" if cfg["modlog_channel_id"] else "Ayarlanmadı", inline=True)
        embed.add_field(name="Karşılama", value=f"<#{cfg['welcome_channel_id']}>" if cfg["welcome_channel_id"] else "Ayarlanmadı", inline=True)
        await ctx.send(embed=embed)

    @commands.command(name="öneriver", aliases=["megaöneri"])
    @commands.guild_only()
    @commands.cooldown(1, 30, commands.BucketType.user)
    async def create_suggestion(self, ctx: commands.Context, *, text: str) -> None:
        clean = self.clean_text(text, 900)
        if len(clean) < 10:
            await ctx.send("Önerin en az 10 karakter olsun")
            return
        cfg = self.get_config(ctx.guild.id)
        channel_id = cfg["suggestions_channel_id"]
        channel = ctx.guild.get_channel(int(channel_id)) if channel_id else ctx.channel
        embed = discord.Embed(title="Yeni topluluk önerisi", description=clean, color=discord.Color.blurple(), timestamp=datetime.now(timezone.utc))
        embed.set_author(name=ctx.author.display_name, icon_url=ctx.author.display_avatar.url)
        try:
            message = await channel.send(embed=embed)
            await message.add_reaction("👍")
            await message.add_reaction("👎")
        except discord.HTTPException:
            await ctx.send("Öneri mesajı gönderilemedi botun kanal izinlerini kontrol et")
            return
        self.db.execute(
            "INSERT INTO mega_suggestions(guild_id,user_id,message_id,channel_id,text,created_at) VALUES(?,?,?,?,?,?)",
            (ctx.guild.id, ctx.author.id, message.id, channel.id, clean, time.time()),
        )
        self.award_badge(ctx.guild.id, ctx.author.id, "Fikir Üreticisi")
        self.db.execute(
            "INSERT INTO mega_quests(guild_id,user_id,quest_key,quest_date,progress) VALUES(?,?, 'help_1',?,1) "
            "ON CONFLICT(guild_id,user_id,quest_key,quest_date) DO UPDATE SET progress=1",
            (ctx.guild.id, ctx.author.id, self.today()),
        )
        self.db.commit()
        if channel.id != ctx.channel.id:
            await ctx.send(f"Önerin {channel.mention} kanalına gönderildi")

    @commands.command(name="önerikanalayar", aliases=["megaönerikanal"])
    @commands.guild_only()
    @commands.has_guild_permissions(manage_guild=True)
    async def set_suggestions_channel(self, ctx: commands.Context, channel: discord.TextChannel) -> None:
        self.db.execute("INSERT OR IGNORE INTO mega_guild_config(guild_id) VALUES(?)", (ctx.guild.id,))
        self.db.execute("UPDATE mega_guild_config SET suggestions_channel_id=? WHERE guild_id=?", (channel.id, ctx.guild.id))
        self.db.commit()
        await ctx.send(f"Öneriler artık {channel.mention} kanalına gönderilecek")

    async def change_suggestion_status(self, ctx: commands.Context, suggestion_id: int, status: str) -> None:
        row = self.db.execute("SELECT * FROM mega_suggestions WHERE guild_id=? AND id=?", (ctx.guild.id, suggestion_id)).fetchone()
        if not row:
            await ctx.send("Öneri numarası bulunamadı")
            return
        if row["status"] != "pending":
            await ctx.send("Bu öneri daha önce değerlendirilmiş")
            return
        self.db.execute(
            "UPDATE mega_suggestions SET status=?,moderator_id=?,updated_at=? WHERE guild_id=? AND id=?",
            (status, ctx.author.id, time.time(), ctx.guild.id, suggestion_id),
        )
        self.db.commit()
        channel = ctx.guild.get_channel(int(row["channel_id"])) if row["channel_id"] else None
        if channel:
            try:
                message = await channel.fetch_message(int(row["message_id"]))
                embed = message.embeds[0] if message.embeds else discord.Embed(description=row["text"])
                embed.color = discord.Color.green() if status == "approved" else discord.Color.red()
                embed.add_field(name="Durum", value="Onaylandı" if status == "approved" else "Reddedildi", inline=True)
                embed.add_field(name="İnceleyen", value=ctx.author.mention, inline=True)
                await message.edit(embed=embed)
            except (discord.HTTPException, IndexError, TypeError):
                pass
        await ctx.send(f"Öneri {suggestion_id} {'onaylandı' if status == 'approved' else 'reddedildi'}")

    @commands.command(name="önerionayla")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_messages=True)
    async def approve_suggestion(self, ctx: commands.Context, suggestion_id: int) -> None:
        await self.change_suggestion_status(ctx, suggestion_id, "approved")

    @commands.command(name="önerireddet")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_messages=True)
    async def reject_suggestion(self, ctx: commands.Context, suggestion_id: int) -> None:
        await self.change_suggestion_status(ctx, suggestion_id, "rejected")

    @commands.command(name="öneriler")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_messages=True)
    async def list_suggestions(self, ctx: commands.Context, status: str = "pending") -> None:
        status = self.normalize(status)
        if status not in ("pending", "approved", "rejected"):
            await ctx.send("Durum pending approved veya rejected olmalı")
            return
        rows = self.db.execute(
            "SELECT id,user_id,text,created_at FROM mega_suggestions WHERE guild_id=? AND status=? ORDER BY id DESC LIMIT 15",
            (ctx.guild.id, status),
        ).fetchall()
        if not rows:
            await ctx.send("Bu durumda öneri yok")
            return
        lines = [f"`#{row['id']}` <@{row['user_id']}> · {row['text'][:130]}" for row in rows]
        await ctx.send(embed=discord.Embed(title=f"Öneriler · {status}", description="\n".join(lines), color=discord.Color.blurple()))

    @commands.command(name="avatar")
    async def avatar(self, ctx: commands.Context, member: Optional[discord.Member] = None) -> None:
        member = member or ctx.author
        embed = discord.Embed(title=f"{member.display_name} · Avatar", color=discord.Color.blurple())
        embed.set_image(url=member.display_avatar.url)
        await ctx.send(embed=embed)

    @commands.command(name="banner")
    async def banner(self, ctx: commands.Context, user: Optional[discord.User] = None) -> None:
        user = user or ctx.author
        try:
            user = await self.bot.fetch_user(user.id)
        except discord.HTTPException:
            pass
        if not user.banner:
            await ctx.send("Bu kullanıcının herkese açık profil bannerı yok")
            return
        embed = discord.Embed(title=f"{user.name} · Banner", color=discord.Color.blurple())
        embed.set_image(url=user.banner.url)
        await ctx.send(embed=embed)

    @commands.command(name="kullanıcıbilgisi", aliases=["kullanicibilgisi", "kimlik"])
    @commands.guild_only()
    async def user_information(self, ctx: commands.Context, member: Optional[discord.Member] = None) -> None:
        member = member or ctx.author
        embed = discord.Embed(title=f"{member.display_name} · Kullanıcı bilgisi", color=member.color if member.color.value else discord.Color.blurple())
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="Kullanıcı adı", value=str(member), inline=True)
        embed.add_field(name="Kullanıcı ID", value=str(member.id), inline=True)
        embed.add_field(name="Hesap tarihi", value=f"<t:{int(member.created_at.timestamp())}:D>", inline=True)
        embed.add_field(name="Sunucuya katılma", value=f"<t:{int(member.joined_at.timestamp())}:D>" if member.joined_at else "Bilinmiyor", inline=True)
        embed.add_field(name="En yüksek rol", value=member.top_role.mention, inline=True)
        embed.add_field(name="Bot hesabı", value="Evet" if member.bot else "Hayır", inline=True)
        await ctx.send(embed=embed)

    @commands.command(name="kanalbilgisi", aliases=["kanalbilgi"])
    @commands.guild_only()
    async def channel_information(self, ctx: commands.Context, channel: Optional[discord.TextChannel] = None) -> None:
        channel = channel or ctx.channel
        embed = discord.Embed(title=f"#{channel.name} · Kanal bilgisi", description=channel.topic or "Kanal konusu ayarlanmamış", color=discord.Color.blurple())
        embed.add_field(name="ID", value=str(channel.id), inline=True)
        embed.add_field(name="Kategori", value=channel.category.name if channel.category else "Yok", inline=True)
        embed.add_field(name="Yavaş mod", value=f"{channel.slowmode_delay} saniye", inline=True)
        embed.add_field(name="Oluşturulma", value=f"<t:{int(channel.created_at.timestamp())}:D>", inline=True)
        await ctx.send(embed=embed)

    @commands.command(name="rolbilgisi", aliases=["rolbilgi"])
    @commands.guild_only()
    async def role_information(self, ctx: commands.Context, role: discord.Role) -> None:
        permissions = [name.replace("_", " ") for name, value in role.permissions if value]
        embed = discord.Embed(title=f"{role.name} · Rol bilgisi", color=role.color if role.color.value else discord.Color.blurple())
        embed.add_field(name="ID", value=str(role.id), inline=True)
        embed.add_field(name="Üye sayısı", value=str(len(role.members)), inline=True)
        embed.add_field(name="Entegrasyon rolü", value="Evet" if role.managed else "Hayır", inline=True)
        embed.add_field(name="Yetkiler", value=", ".join(permissions[:20]) or "Özel yetki yok", inline=False)
        await ctx.send(embed=embed)

    @commands.command(name="emojiler")
    @commands.guild_only()
    async def emoji_list(self, ctx: commands.Context) -> None:
        emojis = ctx.guild.emojis
        if not emojis:
            await ctx.send("Bu sunucuda özel emoji yok")
            return
        lines = [f"{emoji} `{emoji.name}`" for emoji in emojis[:45]]
        await ctx.send(embed=discord.Embed(title=f"{ctx.guild.name} emojileri", description="\n".join(lines), color=discord.Color.blurple()))

    @commands.command(name="tarih")
    async def date_info(self, ctx: commands.Context) -> None:
        now = datetime.now(timezone.utc)
        turkish_days = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"]
        turkish_months = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]
        text = f"{now.day} {turkish_months[now.month - 1]} {now.year} · {turkish_days[now.weekday()]}\nUTC saat: {now:%H:%M:%S}"
        await ctx.send(embed=discord.Embed(title="Tarih ve saat", description=text, color=discord.Color.blurple()))

    @commands.command(name="hesapla")
    async def calculate(self, ctx: commands.Context, *, expression: str) -> None:
        expression = expression.strip()
        if len(expression) > 80 or not re.fullmatch(r"[0-9+\-*/().% ]+", expression):
            await ctx.send("Yalnızca sayılar ve + - * / % parantez işlemleri kullanılabilir")
            return
        def evaluate(node: ast.AST) -> float | int:
            if isinstance(node, ast.Expression):
                return evaluate(node.body)
            if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
                if abs(node.value) > 1e12:
                    raise ValueError("number too large")
                return node.value
            if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd)):
                value = evaluate(node.operand)
                return -value if isinstance(node.op, ast.USub) else value
            if isinstance(node, ast.BinOp):
                left, right = evaluate(node.left), evaluate(node.right)
                if isinstance(node.op, ast.Add): result = left + right
                elif isinstance(node.op, ast.Sub): result = left - right
                elif isinstance(node.op, ast.Mult): result = left * right
                elif isinstance(node.op, ast.Div): result = left / right
                elif isinstance(node.op, ast.FloorDiv): result = left // right
                elif isinstance(node.op, ast.Mod): result = left % right
                elif isinstance(node.op, ast.Pow):
                    if abs(right) > 8: raise ValueError("power too large")
                    result = left ** right
                else: raise ValueError("operation not allowed")
                if not isinstance(result, (int, float)) or abs(result) > 1e18:
                    raise ValueError("result out of range")
                return result
            raise ValueError("syntax not allowed")
        try:
            tree = ast.parse(expression, mode="eval")
            if len(list(ast.walk(tree))) > 40:
                raise ValueError("expression too complex")
            result = evaluate(tree)
            if not math.isfinite(float(result)) or abs(result) > 1e18:
                raise ValueError("result out of range")
            output = f"{result:,}" if isinstance(result, int) else f"{result:,.8g}"
        except (ArithmeticError, SyntaxError, ValueError, TypeError, OverflowError):
            await ctx.send("Bu işlem hesaplanamadı ifadeyi kontrol et")
            return
        await ctx.send(embed=discord.Embed(title="Hesap makinesi", description=f"`{expression}` = **{output}**", color=discord.Color.blurple()))

    @commands.command(name="matematikoyunu", aliases=["matoyun"])
    @commands.guild_only()
    @commands.cooldown(1, 20, commands.BucketType.user)
    async def math_game(self, ctx: commands.Context) -> None:
        a, b = random.randint(5, 40), random.randint(3, 25)
        operation = random.choice(("+", "-", "*"))
        answer = a + b if operation == "+" else a - b if operation == "-" else a * b
        view = MathChallengeView(ctx.author.id, answer, lambda: self.award_game_reward(ctx.guild.id, ctx.author.id, 150))
        await ctx.send(f"**{a} {operation} {b} = ?**\n45 saniye içinde cevapla doğru cevap 150 paklava kazandırır", view=view)

    def award_game_reward(self, guild_id: int, user_id: int, amount: int) -> None:
        self.add_money(guild_id, user_id, amount)

    @commands.command(name="bilgiyarışması", aliases=["bilgiyarismasi", "quiz"])
    @commands.guild_only()
    @commands.cooldown(1, 15, commands.BucketType.user)
    async def trivia_game(self, ctx: commands.Context) -> None:
        question, answer, display = random.choice(TRIVIA_QUESTIONS)
        key = (ctx.guild.id, ctx.author.id)
        self.quiz_sessions[key] = (answer, display, time.time() + 60)
        await ctx.send(f"**Bilgi sorusu**\n{question}\n\nCevabını `B!bilgicevap cevap` ile yaz 60 saniyen var")

    @commands.command(name="bilgicevap", aliases=["quizcevap"])
    @commands.guild_only()
    async def trivia_answer(self, ctx: commands.Context, *, answer: str) -> None:
        key = (ctx.guild.id, ctx.author.id)
        session = self.quiz_sessions.get(key)
        if not session or session[2] < time.time():
            self.quiz_sessions.pop(key, None)
            await ctx.send("Aktif bilgi sorusu yok `B!bilgiyarışması` ile yenisini başlat")
            return
        expected, display, expires = session
        self.quiz_sessions.pop(key, None)
        normalized = self.normalize(answer).replace("'", "")
        valid = normalized == self.normalize(expected) or normalized.replace(" ", "") == self.normalize(expected).replace(" ", "")
        if valid:
            self.add_money(ctx.guild.id, ctx.author.id, 120)
            await ctx.send(f"Doğru cevap **{display}** 120 paklava kazandın")
        else:
            await ctx.send("Cevap doğru değil bir sonraki soruda tekrar dene")

    @commands.command(name="kelimekarıştır", aliases=["kelimekaristir"])
    @commands.guild_only()
    @commands.cooldown(1, 15, commands.BucketType.user)
    async def word_scramble(self, ctx: commands.Context) -> None:
        original = random.choice(WORD_BANK)
        chars = list(original)
        for _ in range(5):
            random.shuffle(chars)
            if "".join(chars) != original:
                break
        scrambled = "".join(chars)
        self.word_sessions[(ctx.guild.id, ctx.author.id)] = (original, scrambled, time.time() + 45)
        await ctx.send(f"Karışık kelime: **{scrambled}**\n45 saniyede `B!kelimecevap kelime` komutuyla çöz")

    @commands.command(name="kelimecevap")
    @commands.guild_only()
    async def word_answer(self, ctx: commands.Context, *, answer: str) -> None:
        key = (ctx.guild.id, ctx.author.id)
        session = self.word_sessions.get(key)
        if not session or session[2] < time.time():
            self.word_sessions.pop(key, None)
            await ctx.send("Aktif kelime oyunun yok")
            return
        original, scrambled, expires = session
        self.word_sessions.pop(key, None)
        if self.normalize(answer) == self.normalize(original):
            self.add_money(ctx.guild.id, ctx.author.id, 100)
            await ctx.send(f"Bildin kelime **{original}** 100 paklava kazandın")
        else:
            await ctx.send(f"Bu kelime değildi doğru cevap **{original}**")

    @commands.command(name="bulmaca")
    @commands.guild_only()
    @commands.cooldown(1, 20, commands.BucketType.user)
    async def riddle(self, ctx: commands.Context) -> None:
        riddles = [
            ("Ne kadar çok alırsan o kadar çok geride bırakırsın", "adim"),
            ("Dili var ama konuşamaz kapağı var ama açamaz", "kitap"),
            ("Her gün doğar ama hiç büyümez", "gunes"),
            ("Kırıldığında işe yarayan şey nedir", "yumurta"),
            ("Şehirleri var evleri yok ormanları var ağaçları yok", "harita"),
            ("Sana ait ama başkaları senden daha çok kullanır", "ad"),
        ]
        question, answer = random.choice(riddles)
        self.word_sessions[(ctx.guild.id, ctx.author.id)] = (answer, "riddle", time.time() + 60)
        await ctx.send(f"**Bulmaca**\n{question}\n\nCevap için `B!bulmaca-cevap yanıt` yaz")

    @commands.command(name="bulmaca-cevap", aliases=["bulmacacevap"])
    @commands.guild_only()
    async def riddle_answer(self, ctx: commands.Context, *, answer: str) -> None:
        key = (ctx.guild.id, ctx.author.id)
        session = self.word_sessions.get(key)
        if not session or session[1] != "riddle" or session[2] < time.time():
            await ctx.send("Aktif bulmacan yok")
            return
        expected = session[0]
        self.word_sessions.pop(key, None)
        if self.normalize(answer) == self.normalize(expected):
            self.add_money(ctx.guild.id, ctx.author.id, 100)
            await ctx.send("Doğru cevap 100 paklava kazandın")
        else:
            await ctx.send("Bu cevap doğru değil")

    @commands.command(name="görevödülleri", aliases=["gorevodulleri"])
    async def quest_rewards(self, ctx: commands.Context) -> None:
        lines = [f"**{quest['title']}** · {quest['description']} · ödül {quest['reward']}" for quest in DAILY_QUESTS.values()]
        await ctx.send(embed=discord.Embed(title="Günlük görev havuzu", description="\n".join(lines), color=discord.Color.gold()))

    @commands.command(name="görevilerleme", aliases=["gorevilerleme"])
    @commands.guild_only()
    async def quest_progress(self, ctx: commands.Context) -> None:
        rows = self.db.execute(
            "SELECT quest_key,progress,claimed FROM mega_quests WHERE guild_id=? AND user_id=? AND quest_date=? ORDER BY quest_key",
            (ctx.guild.id, ctx.author.id, self.today()),
        ).fetchall()
        if not rows:
            await ctx.send("Bugünkü görevlerin henüz başlamadı mesaj ve komut kullanarak ilerleme kazanabilirsin")
            return
        lines = []
        for row in rows:
            quest = DAILY_QUESTS.get(row["quest_key"])
            if quest:
                lines.append(f"**{quest['title']}** · {min(row['progress'], quest['target'])}/{quest['target']} · {'ödül alındı' if row['claimed'] else 'devam ediyor'}")
        await ctx.send(embed=discord.Embed(title="Günlük görev ilerlemen", description="\n".join(lines) or "Görev yok", color=discord.Color.gold()))

    @commands.command(name="modtemizle", aliases=["temizlebotmesaj"])
    @commands.guild_only()
    @commands.has_permissions(manage_messages=True)
    async def purge_messages(self, ctx: commands.Context, amount: int = 10) -> None:
        amount = max(1, min(amount, 100))
        deleted = await ctx.channel.purge(limit=amount + 1, reason=f"{ctx.author} tarafından mega temizleme")
        note = await ctx.send(f"{max(0, len(deleted) - 1)} mesaj temizlendi")
        await asyncio.sleep(4)
        try:
            await note.delete()
        except discord.HTTPException:
            pass

    @commands.command(name="modsebep", aliases=["modnotekle"])
    @commands.guild_only()
    @commands.has_guild_permissions(moderate_members=True)
    async def mod_reason(self, ctx: commands.Context, member: discord.Member, *, reason: str) -> None:
        reason = self.clean_text(reason, 350)
        await self.send_modlog(ctx.guild, "Yetkili notu", member.id, ctx.author.id, reason)
        await ctx.send(f"{member.mention} için işlem kaydı eklendi")

    @commands.command(name="toplurolver")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_roles=True)
    async def bulk_role_add(self, ctx: commands.Context, role: discord.Role, *members: discord.Member) -> None:
        if not members:
            await ctx.send("Kullanım `B!toplurolver @rol @üye1 @üye2`")
            return
        if len(members) > 10:
            await ctx.send("Bir seferde en fazla 10 üyeye rol verebilirsin")
            return
        if role >= ctx.guild.me.top_role or role.managed or role.is_default():
            await ctx.send("Bot bu rolü veremez rol sırasını kontrol et")
            return
        success, failed = 0, 0
        for member in members:
            try:
                await member.add_roles(role, reason=f"Toplu rol: {ctx.author}")
                success += 1
            except discord.HTTPException:
                failed += 1
        await ctx.send(f"Toplu rol işlemi tamamlandı başarılı {success} başarısız {failed}")

    @commands.command(name="toplurolal")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_roles=True)
    async def bulk_role_remove(self, ctx: commands.Context, role: discord.Role, *members: discord.Member) -> None:
        if not members:
            await ctx.send("Kullanım `B!toplurolal @rol @üye1 @üye2`")
            return
        if len(members) > 10:
            await ctx.send("Bir seferde en fazla 10 üyeden rol alabilirsin")
            return
        if role >= ctx.guild.me.top_role or role.managed or role.is_default():
            await ctx.send("Bot bu rolü yönetemez rol sırasını kontrol et")
            return
        success, failed = 0, 0
        for member in members:
            try:
                await member.remove_roles(role, reason=f"Toplu rol kaldırma: {ctx.author}")
                success += 1
            except discord.HTTPException:
                failed += 1
        await ctx.send(f"Toplu rol kaldırma tamamlandı başarılı {success} başarısız {failed}")

    @commands.command(name="sunucukartı", aliases=["servercard"])
    @commands.guild_only()
    async def server_card(self, ctx: commands.Context) -> None:
        guild = ctx.guild
        embed = discord.Embed(title=f"{guild.name} · Sunucu kartı", description=guild.description or "Sunucu açıklaması yok", color=discord.Color.gold())
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        embed.add_field(name="Üyeler", value=str(guild.member_count), inline=True)
        embed.add_field(name="Kanallar", value=str(len(guild.channels)), inline=True)
        embed.add_field(name="Roller", value=str(len(guild.roles)), inline=True)
        embed.add_field(name="Oluşturulma", value=f"<t:{int(guild.created_at.timestamp())}:D>", inline=True)
        embed.add_field(name="Sunucu ID", value=str(guild.id), inline=True)
        embed.add_field(name="Sahip", value=f"<@{guild.owner_id}>", inline=True)
        await ctx.send(embed=embed)

    @commands.command(name="geliştiricibilgi", aliases=["botbilgi2"])
    async def developer_info(self, ctx: commands.Context) -> None:
        embed = discord.Embed(title="Baklava1923 Bot 3.6.2 MEGA", description="Ekonomi · kulüpler · koleksiyon · oyunlar · güvenlik · sunucu yönetimi", color=discord.Color.gold())
        embed.add_field(name="Python", value=os.sys.version.split()[0], inline=True)
        embed.add_field(name="discord.py", value=discord.__version__, inline=True)
        embed.add_field(name="Sunucular", value=str(len(self.bot.guilds)), inline=True)
        embed.add_field(name="Prefix", value="`!` · `B!` · `b!`", inline=True)
        embed.add_field(name="Yeni modül", value="MEGA expansion", inline=True)
        await ctx.send(embed=embed)

    @commands.command(name="baklava-destek")
    async def support_info(self, ctx: commands.Context) -> None:
        await ctx.send("Baklava1923 Bot komutları için `B!yardim` ve yeni sistemler için `B!mega-yardim` kullan")

    @commands.command(name="görevödül", aliases=["gorevodul", "gorevtopla"])
    @commands.guild_only()
    async def claim_daily_quest(self, ctx: commands.Context) -> None:
        today = self.today()
        rows = self.db.execute(
            "SELECT quest_key,progress,claimed FROM mega_quests WHERE guild_id=? AND user_id=? AND quest_date=?",
            (ctx.guild.id, ctx.author.id, today),
        ).fetchall()
        earned = 0
        claimed_names = []
        for row in rows:
            quest = DAILY_QUESTS.get(row["quest_key"])
            if not quest or row["claimed"] or int(row["progress"]) < int(quest["target"]):
                continue
            self.db.execute(
                "UPDATE mega_quests SET claimed=1 WHERE guild_id=? AND user_id=? AND quest_key=? AND quest_date=? AND claimed=0",
                (ctx.guild.id, ctx.author.id, row["quest_key"], today),
            )
            if self.db.execute("SELECT changes()").fetchone()[0]:
                earned += int(quest["reward"])
                claimed_names.append(quest["title"])
        if not claimed_names:
            await ctx.send("Henüz tamamlayıp ödülünü alabileceğin görev yok `B!görevilerleme` ile ilerlemene bak")
            return
        self.add_money(ctx.guild.id, ctx.author.id, earned)
        if len(claimed_names) >= 3:
            self.award_badge(ctx.guild.id, ctx.author.id, "Görev Ustası")
        else:
            self.award_badge(ctx.guild.id, ctx.author.id, "İlk Görev")
        await ctx.send(f"Tamamlanan görevler: {', '.join(claimed_names)}\nToplam ödül: **{earned:,}** paklava")

    @commands.command(name="mesajistatistik", aliases=["mesajlarim"])
    @commands.guild_only()
    async def message_statistics(self, ctx: commands.Context, member: Optional[discord.Member] = None) -> None:
        member = member or ctx.author
        row = self.db.execute(
            "SELECT message_count,command_count FROM mega_message_stats WHERE guild_id=? AND user_id=? AND stat_date=?",
            (ctx.guild.id, member.id, self.today()),
        ).fetchone()
        messages = int(row["message_count"]) if row else 0
        commands_used = int(row["command_count"]) if row else 0
        embed = discord.Embed(title=f"{member.display_name} · Bugünkü aktivite", color=discord.Color.blurple())
        embed.add_field(name="Mesaj", value=f"{messages:,}", inline=True)
        embed.add_field(name="Komut", value=f"{commands_used:,}", inline=True)
        embed.add_field(name="Toplam etkileşim", value=f"{messages + commands_used:,}", inline=True)
        await ctx.send(embed=embed)

    @commands.command(name="toplulukistatistik")
    @commands.guild_only()
    async def community_statistics(self, ctx: commands.Context) -> None:
        today = self.today()
        row = self.db.execute(
            "SELECT COUNT(DISTINCT user_id),COALESCE(SUM(message_count),0),COALESCE(SUM(command_count),0) "
            "FROM mega_message_stats WHERE guild_id=? AND stat_date=?",
            (ctx.guild.id, today),
        ).fetchone()
        club_count = self.db.execute("SELECT COUNT(*) FROM mega_clubs WHERE guild_id=?", (ctx.guild.id,)).fetchone()[0]
        suggestion_count = self.db.execute("SELECT COUNT(*) FROM mega_suggestions WHERE guild_id=?", (ctx.guild.id,)).fetchone()[0]
        embed = discord.Embed(title=f"{ctx.guild.name} · Mega topluluk istatistikleri", color=discord.Color.gold())
        embed.add_field(name="Bugün aktif kullanıcı", value=str(row[0]), inline=True)
        embed.add_field(name="Bugünkü mesaj", value=f"{row[1]:,}", inline=True)
        embed.add_field(name="Bugünkü komut", value=f"{row[2]:,}", inline=True)
        embed.add_field(name="Kulüp", value=str(club_count), inline=True)
        embed.add_field(name="Öneri", value=str(suggestion_count), inline=True)
        embed.add_field(name="Sunucu üyesi", value=str(ctx.guild.member_count), inline=True)
        await ctx.send(embed=embed)

    @commands.command(name="profilunvanı", aliases=["profilunvani", "unvanayar"])
    @commands.guild_only()
    async def profile_title(self, ctx: commands.Context, *, title: str) -> None:
        title = self.clean_text(title, 32)
        if not title:
            await ctx.send("Unvan boş olamaz")
            return
        self.db.execute(
            "INSERT INTO mega_profiles(guild_id,user_id,profile_title,updated_at) VALUES(?,?,?,?) "
            "ON CONFLICT(guild_id,user_id) DO UPDATE SET profile_title=excluded.profile_title,updated_at=excluded.updated_at",
            (ctx.guild.id, ctx.author.id, title, time.time()),
        )
        self.db.commit()
        await ctx.send(f"Profil unvanın **{title}** olarak kaydedildi")

    @commands.command(name="kulüplideraktar", aliases=["kuluplideraktar"])
    @commands.guild_only()
    async def transfer_club_leadership(self, ctx: commands.Context, member: discord.Member) -> None:
        if member.bot or member.id == ctx.author.id:
            await ctx.send("Liderliği başka bir gerçek üyeye devretmelisin")
            return
        own = self.db.execute(
            "SELECT club_id,role FROM mega_club_members WHERE guild_id=? AND user_id=?",
            (ctx.guild.id, ctx.author.id),
        ).fetchone()
        target = self.db.execute(
            "SELECT club_id FROM mega_club_members WHERE guild_id=? AND user_id=?",
            (ctx.guild.id, member.id),
        ).fetchone()
        if not own or own["role"] != "leader" or not target or int(target[0]) != int(own["club_id"]):
            await ctx.send("Bu işlem için kulüp lideri olmalı ve hedef üye aynı kulüpte bulunmalı")
            return
        self.db.execute("UPDATE mega_club_members SET role='member' WHERE guild_id=? AND club_id=? AND user_id=?", (ctx.guild.id, own["club_id"], ctx.author.id))
        self.db.execute("UPDATE mega_club_members SET role='leader' WHERE guild_id=? AND club_id=? AND user_id=?", (ctx.guild.id, own["club_id"], member.id))
        self.db.execute("UPDATE mega_clubs SET owner_id=? WHERE guild_id=? AND id=?", (member.id, ctx.guild.id, own["club_id"]))
        self.db.commit()
        await ctx.send(f"Kulüp liderliği {member.mention} kullanıcısına devredildi")

    @commands.command(name="kulüpbankası", aliases=["kulupbankasi"])
    @commands.guild_only()
    async def club_bank(self, ctx: commands.Context) -> None:
        row = self.db.execute(
            "SELECT c.name,c.bank,m.contribution,m.role FROM mega_club_members m "
            "JOIN mega_clubs c ON c.id=m.club_id AND c.guild_id=m.guild_id "
            "WHERE m.guild_id=? AND m.user_id=?",
            (ctx.guild.id, ctx.author.id),
        ).fetchone()
        if not row:
            await ctx.send("Bir kulübe katılarak kulüp bankasını kullanabilirsin")
            return
        await ctx.send(f"**{row['name']}** kulüp bankası **{row['bank']:,}** · kişisel katkın **{row['contribution']:,}** · rolün {row['role']}")

    @commands.command(name="pazaraekle", aliases=["pazarkur"])
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def market_list_item(self, ctx: commands.Context, item_key: str, quantity: int, unit_price: int) -> None:
        item_key = self.normalize(item_key).replace(" ", "_")
        if item_key not in SHOP_CATALOG or not 1 <= quantity <= 50 or not 1 <= unit_price <= 1_000_000:
            await ctx.send("Geçerli bir koleksiyon eşyası, 1-50 miktar ve 1-1000000 birim fiyat yaz")
            return
        try:
            self.db.execute("BEGIN IMMEDIATE")
            row = self.db.execute(
                "SELECT quantity FROM mega_inventory WHERE guild_id=? AND user_id=? AND item_key=?",
                (ctx.guild.id, ctx.author.id, item_key),
            ).fetchone()
            if not row or int(row[0]) < quantity:
                self.db.rollback()
                await ctx.send("Pazara koymak için yeterli eşyan yok")
                return
            self.db.execute(
                "UPDATE mega_inventory SET quantity=quantity-? WHERE guild_id=? AND user_id=? AND item_key=?",
                (quantity, ctx.guild.id, ctx.author.id, item_key),
            )
            self.db.execute(
                "INSERT INTO mega_market_listings(guild_id,seller_id,item_key,quantity,unit_price,created_at) VALUES(?,?,?,?,?,?)",
                (ctx.guild.id, ctx.author.id, item_key, quantity, unit_price, time.time()),
            )
            listing_id = int(self.db.execute("SELECT last_insert_rowid()").fetchone()[0])
            self.db.commit()
        except sqlite3.Error:
            self.db.rollback()
            await ctx.send("Pazar ilanı oluşturulamadı")
            return
        await ctx.send(f"İlan açıldı `#{listing_id}` · {SHOP_CATALOG[item_key]['name']} × {quantity} · birim fiyat {unit_price:,}")

    @commands.command(name="pazar")
    @commands.guild_only()
    async def market_list(self, ctx: commands.Context, page: int = 1) -> None:
        page = max(1, min(page, 20))
        rows = self.db.execute(
            "SELECT id,seller_id,item_key,quantity,unit_price FROM mega_market_listings "
            "WHERE guild_id=? AND status='open' ORDER BY id DESC LIMIT 10 OFFSET ?",
            (ctx.guild.id, (page - 1) * 10),
        ).fetchall()
        if not rows:
            await ctx.send("Pazarda açık ilan yok")
            return
        lines = []
        for row in rows:
            item = SHOP_CATALOG.get(row["item_key"], {"name": row["item_key"]})
            lines.append(f"`#{row['id']}` **{item['name']}** × {row['quantity']} · adet {row['unit_price']:,} · satıcı <@{row['seller_id']}>")
        await ctx.send(embed=discord.Embed(title=f"Baklava oyuncu pazarı · Sayfa {page}", description="\n".join(lines) + "\n\nSatın almak için `B!pazardan-al ilan_no miktar`", color=discord.Color.gold()))

    @commands.command(name="pazardan-al", aliases=["pazarsatinal"])
    @commands.guild_only()
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def market_buy(self, ctx: commands.Context, listing_id: int, quantity: int = 1) -> None:
        if quantity < 1 or quantity > 50:
            await ctx.send("Miktar 1-50 arasında olmalı")
            return
        try:
            self.db.execute("BEGIN IMMEDIATE")
            listing = self.db.execute(
                "SELECT * FROM mega_market_listings WHERE guild_id=? AND id=? AND status='open'",
                (ctx.guild.id, listing_id),
            ).fetchone()
            if not listing:
                self.db.rollback()
                await ctx.send("Açık ilan bulunamadı")
                return
            if int(listing["seller_id"]) == ctx.author.id:
                self.db.rollback()
                await ctx.send("Kendi ilanını satın alamazsın")
                return
            if quantity > int(listing["quantity"]):
                self.db.rollback()
                await ctx.send("İlanda bu kadar ürün kalmamış")
                return
            total = quantity * int(listing["unit_price"])
            self.ensure_account(ctx.guild.id, ctx.author.id)
            buyer = self.db.execute("SELECT balance FROM economy WHERE guild_id=? AND user_id=?", (ctx.guild.id, ctx.author.id)).fetchone()
            if not buyer or int(buyer[0]) < total:
                self.db.rollback()
                await ctx.send(f"Bu alışveriş için **{total:,}** paklava gerekiyor")
                return
            self.db.execute("UPDATE economy SET balance=balance-? WHERE guild_id=? AND user_id=?", (total, ctx.guild.id, ctx.author.id))
            self.ensure_account(ctx.guild.id, int(listing["seller_id"]))
            self.db.execute("UPDATE economy SET balance=balance+? WHERE guild_id=? AND user_id=?", (total, ctx.guild.id, int(listing["seller_id"])))
            self.db.execute(
                "INSERT INTO mega_inventory(guild_id,user_id,item_key,quantity) VALUES(?,?,?,?) "
                "ON CONFLICT(guild_id,user_id,item_key) DO UPDATE SET quantity=quantity+excluded.quantity",
                (ctx.guild.id, ctx.author.id, listing["item_key"], quantity),
            )
            remaining = int(listing["quantity"]) - quantity
            self.db.execute(
                "UPDATE mega_market_listings SET quantity=?,status=? WHERE id=?",
                (remaining, "open" if remaining else "sold", listing_id),
            )
            self.db.commit()
        except sqlite3.Error:
            self.db.rollback()
            await ctx.send("Pazar alışverişi kaydedilemedi")
            return
        item = SHOP_CATALOG.get(listing["item_key"], {"name": listing["item_key"]})
        await ctx.send(f"**{item['name']}** × {quantity} satın aldın · satıcıya **{total:,}** paklava aktarıldı")

    @commands.command(name="pazarilaniptal", aliases=["pazariptal"])
    @commands.guild_only()
    async def market_cancel(self, ctx: commands.Context, listing_id: int) -> None:
        try:
            self.db.execute("BEGIN IMMEDIATE")
            listing = self.db.execute(
                "SELECT * FROM mega_market_listings WHERE guild_id=? AND id=? AND status='open'",
                (ctx.guild.id, listing_id),
            ).fetchone()
            if not listing or int(listing["seller_id"]) != ctx.author.id:
                self.db.rollback()
                await ctx.send("Açık ve sana ait bir ilan bulunamadı")
                return
            self.db.execute(
                "INSERT INTO mega_inventory(guild_id,user_id,item_key,quantity) VALUES(?,?,?,?) "
                "ON CONFLICT(guild_id,user_id,item_key) DO UPDATE SET quantity=quantity+excluded.quantity",
                (ctx.guild.id, ctx.author.id, listing["item_key"], listing["quantity"]),
            )
            self.db.execute("UPDATE mega_market_listings SET status='cancelled' WHERE id=?", (listing_id,))
            self.db.commit()
        except sqlite3.Error:
            self.db.rollback()
            await ctx.send("İlan iptal edilemedi")
            return
        await ctx.send(f"`#{listing_id}` ilanı iptal edildi ürünlerin envanterine döndü")

    @commands.command(name="tarifler")
    async def recipes(self, ctx: commands.Context) -> None:
        lines = [
            "`rozet_seti` → 1 minik_rozet + 1 not_defteri + 250 paklava",
            "`koleksiyon_paketi` → 1 baklava_kutusu + 1 dijital_anahtar + 500 paklava",
            "`yildiz_koleksiyonu` → 1 yildiz_rozet + 1 altin_kasik + 1000 paklava",
        ]
        await ctx.send(embed=discord.Embed(title="Üretim tarifleri", description="\n".join(lines) + "\n\n`B!üret tarif_kodu`", color=discord.Color.gold()))

    @commands.command(name="üret", aliases=["uret", "craft"])
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def craft_item(self, ctx: commands.Context, recipe_key: str) -> None:
        recipe_key = self.normalize(recipe_key).replace(" ", "_")
        recipes = {
            "rozet_seti": ({"minik_rozet": 1, "not_defteri": 1}, 250, "yildiz_rozet"),
            "koleksiyon_paketi": ({"baklava_kutusu": 1, "dijital_anahtar": 1}, 500, "mini_heykel"),
            "yildiz_koleksiyonu": ({"yildiz_rozet": 1, "altin_kasik": 1}, 1000, "baklava_taci"),
        }
        recipe = recipes.get(recipe_key)
        if not recipe:
            await ctx.send("Tarif bulunamadı `B!tarifler` komutunu kullan")
            return
        ingredients, fee, output = recipe
        try:
            self.db.execute("BEGIN IMMEDIATE")
            self.ensure_account(ctx.guild.id, ctx.author.id)
            balance = self.db.execute("SELECT balance FROM economy WHERE guild_id=? AND user_id=?", (ctx.guild.id, ctx.author.id)).fetchone()[0]
            if balance < fee:
                self.db.rollback()
                await ctx.send(f"Üretim bedeli için {fee} paklava gerekli")
                return
            for key, needed in ingredients.items():
                row = self.db.execute("SELECT quantity FROM mega_inventory WHERE guild_id=? AND user_id=? AND item_key=?", (ctx.guild.id, ctx.author.id, key)).fetchone()
                if not row or int(row[0]) < needed:
                    self.db.rollback()
                    await ctx.send(f"Eksik malzeme: **{SHOP_CATALOG[key]['name']}** × {needed}")
                    return
            for key, needed in ingredients.items():
                self.db.execute("UPDATE mega_inventory SET quantity=quantity-? WHERE guild_id=? AND user_id=? AND item_key=?", (needed, ctx.guild.id, ctx.author.id, key))
            self.db.execute("UPDATE economy SET balance=balance-? WHERE guild_id=? AND user_id=?", (fee, ctx.guild.id, ctx.author.id))
            self.db.execute(
                "INSERT INTO mega_inventory(guild_id,user_id,item_key,quantity) VALUES(?,?,?,1) "
                "ON CONFLICT(guild_id,user_id,item_key) DO UPDATE SET quantity=quantity+1",
                (ctx.guild.id, ctx.author.id, output),
            )
            self.db.commit()
        except sqlite3.Error:
            self.db.rollback()
            await ctx.send("Üretim işlemi kaydedilemedi")
            return
        await ctx.send(f"Üretim tamamlandı envanterine **{SHOP_CATALOG[output]['name']}** eklendi")

    @commands.command(name="etkinlikbaşlat", aliases=["etkinlikbaslat"])
    @commands.guild_only()
    @commands.has_guild_permissions(manage_guild=True)
    async def create_event(self, ctx: commands.Context, day: str, clock: str, *, title: str) -> None:
        try:
            local = datetime.strptime(f"{day} {clock}", "%Y-%m-%d %H:%M").replace(tzinfo=timezone.utc)
        except ValueError:
            await ctx.send("Tarih biçimi `YYYY-MM-DD HH:MM` olmalı saat UTC olarak kaydedilir")
            return
        now = datetime.now(timezone.utc)
        if not now + timedelta(minutes=5) <= local <= now + timedelta(days=60):
            await ctx.send("Etkinlik 5 dakika ile 60 gün arasındaki bir tarihe ayarlanmalı")
            return
        title = self.clean_text(title, 90)
        self.db.execute(
            "INSERT INTO mega_events(guild_id,creator_id,title,starts_at,created_at) VALUES(?,?,?,?,?)",
            (ctx.guild.id, ctx.author.id, title, local.timestamp(), time.time()),
        )
        event_id = int(self.db.execute("SELECT last_insert_rowid()").fetchone()[0])
        self.db.commit()
        await ctx.send(f"Sunucu etkinliği oluşturuldu `#{event_id}` · **{title}** · <t:{int(local.timestamp())}:F> UTC")

    @commands.command(name="etkinlikler")
    @commands.guild_only()
    async def list_events(self, ctx: commands.Context) -> None:
        rows = self.db.execute(
            "SELECT id,title,starts_at,status FROM mega_events WHERE guild_id=? AND status='open' AND starts_at>? ORDER BY starts_at LIMIT 15",
            (ctx.guild.id, time.time()),
        ).fetchall()
        if not rows:
            await ctx.send("Yaklaşan etkinlik yok")
            return
        lines = []
        for row in rows:
            count = self.db.execute("SELECT COUNT(*) FROM mega_event_members WHERE event_id=?", (row["id"],)).fetchone()[0]
            lines.append(f"`#{row['id']}` **{row['title']}** · <t:{int(row['starts_at'])}:F> · {count} katılımcı")
        await ctx.send(embed=discord.Embed(title="Yaklaşan sunucu etkinlikleri", description="\n".join(lines), color=discord.Color.gold()))

    @commands.command(name="etkinlikkatıl", aliases=["etkinlikkatil"])
    @commands.guild_only()
    async def join_event(self, ctx: commands.Context, event_id: int) -> None:
        event = self.db.execute(
            "SELECT title,starts_at FROM mega_events WHERE guild_id=? AND id=? AND status='open'",
            (ctx.guild.id, event_id),
        ).fetchone()
        if not event or float(event["starts_at"]) <= time.time():
            await ctx.send("Katılınabilir bir etkinlik bulunamadı")
            return
        self.db.execute("INSERT OR IGNORE INTO mega_event_members(event_id,user_id,joined_at) VALUES(?,?,?)", (event_id, ctx.author.id, time.time()))
        inserted = self.db.execute("SELECT changes()").fetchone()[0]
        self.db.commit()
        await ctx.send("Etkinliğe katılımın kaydedildi" if inserted else "Bu etkinliğe zaten katılmışsın")

    @commands.command(name="etkinlikayrıl", aliases=["etkinlikayril"])
    @commands.guild_only()
    async def leave_event(self, ctx: commands.Context, event_id: int) -> None:
        self.db.execute("DELETE FROM mega_event_members WHERE event_id=? AND user_id=?", (event_id, ctx.author.id))
        removed = self.db.execute("SELECT changes()").fetchone()[0]
        self.db.commit()
        await ctx.send("Etkinlikten ayrıldın" if removed else "Bu etkinliğe kayıtlı değilsin")

    @commands.command(name="etkinlikkatılımcıları", aliases=["etkinlikkatilimcilari"])
    @commands.guild_only()
    @commands.has_guild_permissions(manage_guild=True)
    async def event_participants(self, ctx: commands.Context, event_id: int) -> None:
        rows = self.db.execute(
            "SELECT user_id FROM mega_event_members WHERE event_id=? ORDER BY joined_at LIMIT 50",
            (event_id,),
        ).fetchall()
        if not rows:
            await ctx.send("Bu etkinliğe kayıtlı katılımcı yok")
            return
        await ctx.send("**Etkinlik katılımcıları**\n" + "\n".join(f"<@{row['user_id']}>" for row in rows))

    @commands.command(name="veriözeti", aliases=["veriozeti"])
    @commands.guild_only()
    @commands.has_guild_permissions(administrator=True)
    async def database_summary(self, ctx: commands.Context) -> None:
        tables = ["mega_daily", "mega_profiles", "mega_clubs", "mega_suggestions", "mega_market_listings", "mega_events", "mega_modlog"]
        lines = []
        for table in tables:
            count = self.db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
            lines.append(f"`{table}` · {count:,} kayıt")
        db_size = os.path.getsize(DB_PATH) if os.path.exists(DB_PATH) else 0
        embed = discord.Embed(title="Mega veritabanı özeti", description="\n".join(lines), color=discord.Color.blurple())
        embed.add_field(name="SQLite dosyası", value=f"{db_size / 1024:.1f} KB", inline=False)
        await ctx.send(embed=embed)

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member) -> None:
        cfg = self.get_config(member.guild.id)
        channel_id = cfg["welcome_channel_id"]
        if not channel_id:
            return
        channel = member.guild.get_channel(int(channel_id))
        if channel is None:
            return
        embed = discord.Embed(
            title="Sunucuya hoş geldin",
            description=f"{member.mention} aramıza katıldı\nSunucuda **{member.guild.member_count}** kişi olduk",
            color=discord.Color.green(),
            timestamp=datetime.now(timezone.utc),
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        try:
            await channel.send(embed=embed)
        except discord.HTTPException:
            pass

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member) -> None:
        await self.send_modlog(member.guild, "Üye ayrıldı", member.id, None, f"{member} sunucudan ayrıldı")

    @commands.Cog.listener()
    async def on_message_delete(self, message: discord.Message) -> None:
        if not message.guild or message.author.bot:
            return
        summary = self.clean_text(message.content or "İçerik yok veya ek dosya", 300)
        await self.send_modlog(message.guild, "Mesaj silindi", message.author.id, None, f"Kanal #{getattr(message.channel, 'name', 'bilinmiyor')} · {summary}")

    @commands.Cog.listener()
    async def on_message_edit(self, before: discord.Message, after: discord.Message) -> None:
        if not before.guild or before.author.bot or before.content == after.content:
            return
        old_text = self.clean_text(before.content or "Boş", 160)
        new_text = self.clean_text(after.content or "Boş", 160)
        await self.send_modlog(before.guild, "Mesaj düzenlendi", before.author.id, None, f"Önce: {old_text} · Sonra: {new_text}")

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel) -> None:
        await self.send_modlog(channel.guild, "Kanal silindi", channel.id, None, f"#{channel.name}")

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        if not message.guild or message.author.bot or message.webhook_id:
            return
        if message.author.id == OWNER_ID or message.author.guild_permissions.manage_messages:
            return
        cfg = self.get_config(message.guild.id)
        content = message.content or ""
        normalized = self.normalize(content)
        blocked_reason = None
        if cfg["invite_filter"] and INVITE_PATTERN.search(content):
            blocked_reason = "Davet bağlantısı filtresi"
        elif cfg["word_filter"]:
            words = self.db.execute("SELECT word FROM mega_filter_words WHERE guild_id=?", (message.guild.id,)).fetchall()
            for row in words:
                if row["word"] and row["word"] in normalized:
                    blocked_reason = "Sunucu kelime filtresi"
                    break
        if blocked_reason:
            try:
                await message.delete()
            except discord.HTTPException:
                pass
            await self.send_modlog(message.guild, "Otomatik filtre", message.author.id, None, blocked_reason)
            try:
                await message.channel.send(f"{message.author.mention} mesajın sunucu filtresi nedeniyle kaldırıldı", delete_after=5)
            except discord.HTTPException:
                pass
            return
        if cfg["spam_filter"]:
            key = (message.guild.id, message.author.id)
            queue = self.spam_cache[key]
            now = time.monotonic()
            queue.append(now)
            window = max(3, min(30, int(cfg["spam_window"])))
            while queue and now - queue[0] > window:
                queue.popleft()
            if len(queue) > int(cfg["spam_limit"]):
                queue.clear()
                try:
                    await message.delete()
                except discord.HTTPException:
                    pass
                await self.send_modlog(message.guild, "Spam filtresi", message.author.id, None, f"{window} saniye içinde fazla mesaj")
                try:
                    await message.channel.send(f"{message.author.mention} yavaşla lütfen spam filtresi devreye girdi", delete_after=5)
                except discord.HTTPException:
                    pass
                return
        today = self.today()
        self.db.execute(
            "INSERT INTO mega_message_stats(guild_id,user_id,stat_date,message_count) VALUES(?,?,?,1) "
            "ON CONFLICT(guild_id,user_id,stat_date) DO UPDATE SET message_count=message_count+1",
            (message.guild.id, message.author.id, today),
        )
        self.db.execute(
            "INSERT INTO mega_quests(guild_id,user_id,quest_key,quest_date,progress) VALUES(?,?, 'chat_10',?,1) "
            "ON CONFLICT(guild_id,user_id,quest_key,quest_date) DO UPDATE SET progress=MIN(progress+1,10)",
            (message.guild.id, message.author.id, today),
        )
        self.db.execute(
            "INSERT INTO mega_quests(guild_id,user_id,quest_key,quest_date,progress) VALUES(?,?, 'chat_30',?,1) "
            "ON CONFLICT(guild_id,user_id,quest_key,quest_date) DO UPDATE SET progress=MIN(progress+1,30)",
            (message.guild.id, message.author.id, today),
        )
        self.db.commit()
        # Prefix commands continue to the bot's original on_message handler.

    @commands.Cog.listener()
    async def on_voice_state_update(
        self, member: discord.Member, before: discord.VoiceState, after: discord.VoiceState
    ) -> None:
        if member.bot:
            return
        guild_id, user_id = member.guild.id, member.id
        if before.channel is None and after.channel is not None:
            self.db.execute(
                "INSERT OR REPLACE INTO mega_voice_sessions(guild_id,user_id,joined_at) VALUES(?,?,?)",
                (guild_id, user_id, time.time()),
            )
            self.db.commit()
            return
        if before.channel is not None and after.channel is None:
            row = self.db.execute(
                "SELECT joined_at FROM mega_voice_sessions WHERE guild_id=? AND user_id=?",
                (guild_id, user_id),
            ).fetchone()
            self.db.execute("DELETE FROM mega_voice_sessions WHERE guild_id=? AND user_id=?", (guild_id, user_id))
            if row:
                minutes = max(0, min(180, int((time.time() - float(row[0])) // 60)))
                if minutes:
                    self.db.execute(
                        "INSERT INTO mega_quests(guild_id,user_id,quest_key,quest_date,progress) VALUES(?,?, 'voice_15',?,?) "
                        "ON CONFLICT(guild_id,user_id,quest_key,quest_date) DO UPDATE SET progress=MIN(progress+excluded.progress,15)",
                        (guild_id, user_id, self.today(), minutes),
                    )
            self.db.commit()

    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member) -> None:
        if before.roles != after.roles:
            before_ids = {role.id for role in before.roles}
            after_ids = {role.id for role in after.roles}
            added = [role.name for role in after.roles if role.id not in before_ids]
            removed = [role.name for role in before.roles if role.id not in after_ids]
            details = []
            if added:
                details.append("Eklenen: " + ", ".join(added[:8]))
            if removed:
                details.append("Kaldırılan: " + ", ".join(removed[:8]))
            await self.send_modlog(after.guild, "Üye rolleri değişti", after.id, None, " · ".join(details))

    @commands.Cog.listener()
    async def on_guild_role_create(self, role: discord.Role) -> None:
        await self.send_modlog(role.guild, "Rol oluşturuldu", role.id, None, role.name)

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role) -> None:
        await self.send_modlog(role.guild, "Rol silindi", role.id, None, role.name)

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel: discord.abc.GuildChannel) -> None:
        await self.send_modlog(channel.guild, "Kanal oluşturuldu", channel.id, None, channel.name)

    @commands.Cog.listener()
    async def on_command_completion(self, ctx: commands.Context) -> None:
        if not ctx.guild:
            return
        today = self.today()
        self.db.execute(
            "INSERT INTO mega_message_stats(guild_id,user_id,stat_date,command_count) VALUES(?,?,?,1) "
            "ON CONFLICT(guild_id,user_id,stat_date) DO UPDATE SET command_count=command_count+1",
            (ctx.guild.id, ctx.author.id, today),
        )
        self.db.execute(
            "INSERT INTO mega_quests(guild_id,user_id,quest_key,quest_date,progress) VALUES(?,?, 'command_5',?,1) "
            "ON CONFLICT(guild_id,user_id,quest_key,quest_date) DO UPDATE SET progress=MIN(progress+1,5)",
            (ctx.guild.id, ctx.author.id, today),
        )
        self.db.commit()




async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(BaklavaMega(bot))
